<template>
<div class="background">
  <v-alert
      dense
      border="left"
      type="warning"
      v-model="ifAlertWrongUser"
  >
    <strong>不存在该用户，请注册！</strong>
  </v-alert>
  <v-alert
      dense
      border="left"
      type="warning"
      v-model="ifAlertWrongPass"
  >
    <strong>密保错误</strong>
  </v-alert>




  <div style="position: absolute;top:10%;left: 20%;width: 50%;height: 70%;font-family: '楷体'" @click="disCheck">
    <v-form
        ref="form"
        v-model="valid"
        lazy-validation
    >
      <v-text-field
          v-model="id"
          :rules="[idRules.required, idRules.counter]"
          label="请输入你的账号："
          required
      ></v-text-field>
      <v-text-field
          v-model="passsafe"
          label="请输入你的密保："
          required
      ></v-text-field>

      <v-btn
          style="color: #503e2a;font-family: '楷体';font-size: 35px;position: absolute;bottom: 50%;left: 40%; height: 60px;background-color:rgba(0,0,0,0);border:2px solid #503e2a;"
          elevation="16"
          rounded
          @click="check();forget()"
      >找回密码</v-btn>
    </v-form>

  </div>


  <!--  返回-->
  <v-btn
      style="position: absolute;top: 5%;left: 3%;background-color:rgba(0,0,0,0);"
      elevation="2"
      fab
      large
      raised
      rounded
      @click="back"
  ><v-img src="../assets/icons/back.png" style="width: 40px"/></v-btn>

<!--  对话框-->

  <v-dialog
      transition="dialog-bottom-transition"
      max-width="600"
      v-model="passwordDialog"
      style="font-family: 楷体"
  >
    <v-card>
      <v-toolbar
          color="primary"
          dark
      >你的密码是：</v-toolbar>
      <v-card-text>
        <div class="text-h2 pa-12">{{password}}</div>
      </v-card-text>
      点击对话框外退出对话框
    </v-card>
  </v-dialog>







</div>
</template>

<script>
import request from "@/utils/request";

export default {
  name: "forget",


  data(){
    return{
      valid:true,

      id:'',
      passsafe:'',
      canEnter:true,
      password:'',
      passwordDialog:false,
      ifAlertWrongUser:false,ifAlertWrongPass:false,

      idRules: {
        required: value => !!value || '请填写账号',
        counter: value => value.length == 6 || '账号必须是六位数字！',
      },

    }
  },

  methods:{
    back(){
      this.$router.push('/');
    },
    check(){
      this.canEnter=this.$refs.form.validate();
    },
    disCheck(){
      this.ifAlertWrongUser=false;
      this.ifAlertWrongPass=false;
    },


    forget(){
      if (this.canEnter==true){
        request.post("/api/user/forget",{
          id : this.id,
          passsafe:this.passsafe
        }) .then( (response) => {
          console.log(response);
          if (response.code==0) {
            this.password=response.msg;
            this.passwordDialog=true;
          }
          else if (response.code==1)this.ifAlertWrongPass=true;
          else if (response.code==2)this.ifAlertWrongUser=true;
        })
            .catch((error) => {
              console.log(error);
            });
      }
    }




  },


}
</script>

<style scoped>
.background {
  background: url("../assets/background/back04.png") no-repeat;
  background-position: center;
  height: 100%;
  width: 100%;
  background-size: cover;
  position: fixed;
}
</style>