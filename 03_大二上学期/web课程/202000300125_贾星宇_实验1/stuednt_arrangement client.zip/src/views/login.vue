<template>
<div class="background">
  <v-alert
      dense
      border="left"
      type="warning"
      v-model="ifAlertWarning"
  >
    请输入<strong>完整且正确</strong>的信息
  </v-alert>

  <v-alert
      dense
      border="left"
      type="warning"
      v-model="ifAlertWrongPass"
  >
    <strong>密码错误</strong>
  </v-alert>

  <v-alert
      dense
      border="left"
      type="warning"
      v-model="ifAlertWrongUser"
  >
    <strong>不存在该用户，请注册！</strong>
  </v-alert>


  <p id="p-log"
  style="color: #503e2a;font-family: '楷体';font-size: 90px;position: absolute;top: 20%;left: 13%;"
  >登<br>录</p>

  <p id="p-welcome"
     style="color:gold;font-family:华文行楷;font-size: 50px;position: absolute;top: 1%;left: 2%;"
  >欢<br>迎<br>使<br>用<br>“V课”<br>在<br>线<br>选<br>课<br>系<br>统！</p>




  <v-form
      ref="form"
      v-model="valid"
      lazy-validation
  >

  <div style="color: #503e2a;font-family: '楷体';font-size: 50px;">
    <!--            输入信息 账号-->
    <v-text-field
      label="请输入账号……"
      outlined
      counter
      hide-details="auto"
      style="position: absolute;bottom: 66%;left: 25%;width: 700px"
      :rules="[idRules.required, idRules.counter]"
      v-model="id"
      @click="disCheck"
  ></v-text-field>
  </div>
<!--密码-->
  <div style="color: #503e2a;font-family: '楷体';font-size: 50px;">
    <!--            输入信息 密码-->
    <v-text-field
        :type="passwordshow ? 'text' : 'password'"
        :append-icon="passwordshow ? 'mdi-eye' : 'mdi-eye-off'"
        label="请输入密码……"
        outlined
        counter
        hide-details="auto"
        style="position: absolute;bottom: 51%;left: 25%;width: 700px"
        :rules="[passwordRules.required, passwordRules.counter]"
        v-model="password"
        @click="disCheck"
        @click:append="passwordshow = !passwordshow"
    ></v-text-field>
  </div>



    <v-radio-group
        v-model="userType"
        row
        class="userBut"

    >
      <v-radio
          label="我是老师"
          value="0"
          @click="disCheck"
      ></v-radio>
      <v-radio
          label="我是学生"
          value="1"
          @click="disCheck"
      ></v-radio>
    </v-radio-group>

  </v-form>


<!--  登录-->
  <v-btn
      style="color: #503e2a;font-family: '楷体';font-size: 50px;position: absolute;bottom: 30%;left: 25%; height: 60px;background-color:rgba(0,0,0,0);border:2px solid #503e2a;"
      elevation="16"
      rounded
      @click="check();login()"
  >登录</v-btn>
<!--  注册-->
  <v-btn
      style="color: #503e2a;font-family: '楷体';font-size: 50px;position: absolute;bottom: 30%;left: 45%; height: 60px;background-color:rgba(0,0,0,0);border:2px solid #503e2a;"
      elevation="16"
      rounded
      @click="register"
  >注册</v-btn>
<!--  忘记密码  修改密码-->
  <v-btn
      style="color: #503e2a;font-family: '楷体';font-size: 50px;position: absolute;bottom: 30%;left: 65%; height: 60px;background-color:rgba(0,0,0,0);border:2px solid #503e2a;"
      elevation="16"
      rounded
      @click="forget"
  >忘记密码</v-btn>
  <v-btn
      style="color: #503e2a;font-family: '楷体';font-size: 50px;position: absolute;bottom: 20%;left: 65%; height: 60px;background-color:rgba(0,0,0,0);border:2px solid #503e2a;"
      elevation="16"
      rounded
      @click="changePasswordDialog=true;"
  >修改密码</v-btn>
<!--  刷新-->
  <v-btn
      style="color: #503e2a;position: absolute;top: 30%;left: 80%;background-color:rgba(0,0,0,0);"
      elevation="4"
      fab
      large
      raised
      rounded
      @click="clean"
  ><v-img src="../assets/icons/reflesh.png" style="width: 30px"/></v-btn>


<!--  修改密码-->
  <v-dialog
      v-model="changePasswordDialog"
      transition="dialog-bottom-transition"
      max-width="600"
  >
    <v-alert dense border="left" type="warning" v-model="ifAlertWarning">
      请输入<strong>完整且正确</strong>的信息
    </v-alert>
    <v-alert dense border="left" type="warning" v-model="ifAlertEqu">
      新密码不能和旧密码一样！
    </v-alert>
    <v-alert dense border="left" type="warning" v-model="ifAlertFormalPassWrong">
      原密码错误！
    </v-alert>
    <v-alert dense border="left" type="warning" v-model="ifAlertNotExitUser">
      不存在此用户！
    </v-alert>
    <v-alert dense border="left" type="success" v-model="ifAlertSuccess">
      <strong>修改成功！</strong>
    </v-alert>

    <div style="background-color:white;font-family: 楷体;font-size: 25px">
      <v-text-field
          label="请输入账号……"
          outlined counter hide-details="auto"
          :rules="[idRules.required, idRules.counter]"
          v-model="idwhenchange"
          @click="disCheck"
      ></v-text-field>
      <v-text-field
          :type="passwordshow ? 'text' : 'password'"
          :append-icon="passwordshow ? 'mdi-eye' : 'mdi-eye-off'"
          label="请输入原密码……"
          outlined counter hide-details="auto"
          :rules="[passwordRules.required, passwordRules.counter]"
          v-model="formalPassword"
          @click:append="passwordshow = !passwordshow"
          @click="disCheck"
      ></v-text-field>
      <v-text-field
          :type="passwordshow ? 'text' : 'password'"
          :append-icon="passwordshow ? 'mdi-eye' : 'mdi-eye-off'"
          label="请输入新密码……"
          outlined counter hide-details="auto"
          :rules="[passwordRules.required, passwordRules.counter]"
          v-model="nowPassword"
          @click:append="passwordshow = !passwordshow"
          @click="disCheck"

      ></v-text-field>

      <v-btn style="font-size: 25px;background-color:lightskyblue;color: white" @click="changePassWord"
      >确认修改</v-btn>




    </div>
  </v-dialog>














</div>
</template>










<script>
import request from "@/utils/request";

export default {
  name: "login",

  data(){
    return{
      valid:true,//表单元素

      id: '',
      password:'',
      userType:'-1',
      ifAlertWarning:false,ifAlertWrongPass:false,ifAlertWrongUser:false,changePasswordDialog:false,ifAlertEqu:false,
      ifAlertSuccess:false,ifAlertFormalPassWrong:false,ifAlertNotExitUser:false,
      passwordshow:false,
      canEnter : true,

      formalPassword:'',nowPassword:'',idwhenchange:'',




      idRules: {
        required: value => !!value || '请填写账号',
        counter: value => value.length === 6 || '账号必须是六位数字！',
  },
      passwordRules: {
        required: value => !!value || '请填写密码',
        counter: value => value.length === 6 || '密码必须是六位数字！',
      },
    }
  },

  methods:{

    check(){
      this.canEnter=this.$refs.form.validate();
      if (this.userType==-1)this.canEnter=false;
      if(!this.canEnter){
        this.ifAlertWarning=true;
        this.canEnter=false;
      }
    },
    disCheck(){
      this.ifAlertWarning=false;//提示框取消
      this.ifAlertWrongPass=false;
      this.ifAlertWrongUser=false;
      this.ifAlertEqu=false;
      this.ifAlertSuccess=false;
      this.ifAlertFormalPassWrong=false;
      this.ifAlertNotExitUser=false;
    },
    clean(){
      this.$refs.form.reset();
    },
    register(){
      this.$router.push("/register");
    },
    forget(){
      this.$router.push("/forget");
    },

    login(){
      if (this.canEnter==true){
        request.post("/api/user/login",{
          id : this.id,
          password: this.password,
          usertype:this.userType
        }) .then( (response) => {
          console.log(response);
          if (response.code==0) {
            sessionStorage.setItem("userName",response.msg2);
            sessionStorage.setItem("userId",response.msg);
            this.addLoginRecord(response.msg);
            if (this.userType==0)this.$router.push('/teacherGui');
            if (this.userType==1)this.$router.push('/studentGui');
          }
          else if (response.code==1)this.ifAlertWrongPass=true;
          else if (response.code==2)this.ifAlertWrongUser=true;
        })
            .catch((error) => {
              console.log(error);
            });
      }
    },

    changePassWord(){
      if (this.idwhenchange==''||this.formalPassword==''||this.nowPassword=='')this.ifAlertWarning=true;
      else if (this.formalPassword==this.nowPassword)this.ifAlertEqu=true;
      else{
        request.post("/api/user/changePassword",{
          id : this.idwhenchange,
          password: this.formalPassword,
          grade:this.nowPassword,
        }) .then( (response) => {
          console.log(response);
          if (response.code==0) {
            this.ifAlertSuccess=true;
          }
          else if (response.code==1)this.ifAlertWrongPass=true;
          else if (response.code==2)this.ifAlertWrongUser=true;
        })
            .catch((error) => {
              console.log(error);
            });
      }
    },


    //添加一条登录日志
    addLoginRecord(userid){
      request.post("/api/user/addRecord",{
        logintime:new Date(),
        loginuserid:userid,
      }) .then( (response) => {
        console.log(response);
      })
          .catch((error) => {
            console.log(error);
          });
    },


  },


}
</script>

<style scoped>
.background {
  background: url("../assets/background/back01.jpg") no-repeat;
  background-position: center;
  height: 100%;
  width: 100%;
  background-size: cover;
  position: fixed;
}

.userBut{
  font-size:90px;font-family: '楷体';position:absolute;left: 25%;bottom: 43%;
}

</style>