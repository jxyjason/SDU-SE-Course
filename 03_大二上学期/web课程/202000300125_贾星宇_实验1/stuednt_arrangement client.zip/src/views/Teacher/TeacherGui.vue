<template>
<div class="background">
<!--  顶部按钮组-->
  <div style="font-family: 楷体;position: absolute;top:3%;left: 5%; font-size:30px;">欢迎你,{{getUserName}}老师</div>
  <div style="font-family: 楷体;position: absolute;top:0%;left: 31%;">

    <v-btn color="teal" style="height: 30%" tile @click="toCourse">
      <div style="font-size: 30px" ><br>录入课程</div>
    </v-btn>
    <v-btn color="primary" style="height: 30%" tile @click="toScore">
      <div style="font-size: 30px"><br>录入成绩</div>
    </v-btn>
    <v-btn color="info" style="height: 30%" tile disabled>
      <div style="font-size: 30px"><br>我的课程</div>
    </v-btn>
  </div>
  <br><br><br><br>
  <v-divider></v-divider>
  <v-btn color="red" style="font-family: 楷体;position: absolute;right: 0%;bottom: 0%;font-size: 30px;height: 7%"
  @click="exit"
  >退出登录</v-btn>


<!--  提示框-->

  <v-alert
      dense
      border="left"
      type="success"  dismissible
      v-model="ifAlertDelete"
  >
    <strong>删除成功！</strong>
  </v-alert>



<!--主页面-->

  <div style="font-family: '楷体';font-size:15px;overflow:auto;font-weight: bolder;position: absolute;top:15%;left: 10%;width: 70%;height: 70%">
    <div v-for="course in allCourses" :key="course.courseid" >
      <v-chip color="success" outlined style="width: 300px;height: 50px"
              @click="showCourseInfo(course.coursename,course.credit,course.coursedescription,
              course.coursebegtime.split('-')[0],course.coursebegtime.split('-')[1],
              course.coursebegtime.split('-')[2],course.courseendtime.split('-')[0],
              course.courseendtime.split('-')[1],course.choosecoursebegtime,course.choosecourseendtime,
              course.courseid)">
        <v-icon left>mdi-star</v-icon>
        <div style="font-family: '楷体';font-size:15px;">课程：(点击修改课程信息)<br>{{course.coursename}}</div>
      </v-chip>
      <v-chip color="indigo" outlined style="width: 200px;height: 50px"
      @click="getStudentChooseCourse(course.courseid)"
      >
        <v-avatar left>
          <v-icon>mdi-account-circle</v-icon>
        </v-avatar>
        <div style="font-family: '楷体';font-size:17px;">点击查看选课学生</div>
      </v-chip>
      <v-btn tile color="red" outlined style="float: right" @click="deleteMyCourse(course.courseid)">
        删除课程：{{course.coursename}}
      </v-btn>
      <br><br>
    </div>
  </div>

<!--  修改课程对话框-->

  <v-dialog style="border-width: 100px"
      v-model="showdialogcourse"
      transition="dialog-bottom-transition"
      max-width="700"
  >
    <v-card style="color: #503e2a;font-family: '楷体';font-size: 30px;" >
      <v-form
          ref="form"
          v-model="valid"
          lazy-validation
      >
        <v-text-field
            v-model="coursename"
            label="请输入课程名称......"
            :rules="[nameRules.required]"
            required
        ></v-text-field>

        <v-text-field
            v-model="credit"
            label="点击修改课程学分(1-5)……"
            :rules="[creditRules.required,creditRules.counter]"
            required
        ></v-text-field>

        <v-text-field
            v-model="coursedescription"
            label="请输入课程描述......"
            required
        ></v-text-field>
        <v-text-field
            v-model="choosecoursebegtime"
            :rules="[timeRules.form]"
            label="请输入该课程选课开始时间(格式:XXXX-XX-XX)..."
            required
        ></v-text-field>
        <v-text-field
            v-model="choosecourseendtime"
            :rules="[timeRules.form]"
            label="请输入该课程选课截止时间(格式:XXXX-XX-XX)..."
            required
        ></v-text-field>
        <br>

          <v-text-field
              v-model="coursebegweek"
              label="点击修改课程开始周(1-15)……"
              :rules="[weekRules.required,weekRules.counter]"
              required
          ></v-text-field>
          <v-text-field
              v-model="coursebegday"
              label="点击修改课程在周几开设(1-7)……"
              :rules="[dayRules.required,dayRules.counter]"
              required
          ></v-text-field>
          <v-text-field
              v-model="coursebegcou"
              label="点击修改课程在第几节课开设(1-5)……"
              :rules="[couRules.required,couRules.counter]"
              required
          ></v-text-field>



          <v-text-field
              v-model="courseendweek"
              label="点击修改课程结束周(1-15)……"
              :rules="[weekRules.required,weekRules.counter]"
              required
          ></v-text-field>
          <v-text-field
              v-model="courseendday"
              label="点击修改课程在周几结束(1-7)……"
              :rules="[dayRules.required,dayRules.counter]"
              required
          ></v-text-field>

      </v-form>


      <v-alert
          dense
          border="left"
          type="success" dismissible
          v-model="ifAlertSuccess"
      >
        <strong>成功修改课程：{{coursename}}</strong>
      </v-alert>
      <v-alert
          dense
          border="left"
          type="warning" dismissible
          v-model="ifAlertFail"
      >
        <strong>"{{coursename}}"添加失败</strong>
      </v-alert>


      <v-btn style="font-size: 20px;" @click="changeCourseInfo">
        确定修改
      </v-btn>
    </v-card>

  </v-dialog>



<!--显示选课学生对话框-->
  <v-dialog
      v-model="showdialognotexit"
      transition="dialog-bottom-transition"
      max-width="600"
  >
    <v-card style="color: #503e2a;font-family: '楷体';font-size: 30px;" >
      暂时没有学生选择此门课程
      <br>
      <v-btn style="font-size: 30px;" @click="showdialognotexit=false;">
        确定
      </v-btn>
    </v-card>
  </v-dialog>
  <v-dialog
      v-model="showstudentdialog"
      transition="dialog-bottom-transition"
      max-width="1200"
  >
    <div style="color: #503e2a;font-family: '楷体';font-size: 20px;height: auto;background-color:white;"
         v-for="student in students" :key="student.id"
    >
      姓名：{{student.name}}
      班级：{{student.grade}}班
      专业：{{student.major}}
      生日：{{student.birth}}
      邮箱：{{student.email}}
      电话：{{student.phone}}
      地址：{{student.address}}
      <br><br>
    </div>
    <v-btn @click="showstudentdialog=false;" color="indigo"  style="color:white;font-family:楷体;font-size: 20px">确定</v-btn>
  </v-dialog>


<!--确定删除对话框-->
  <v-dialog
      v-model="confirmdeletedialog"
      transition="dialog-bottom-transition"
      max-width="700"
      style="height: 600px"
  >
    <div style="font-family: '楷体';font-size: 25px;background-color:white; color: red">
      确定删除吗？
    </div>
    <v-btn @click="trueDelete" color="red" style="color:white;font-family:楷体;font-size: 20px;width: 90px;"
    >确定</v-btn>
  </v-dialog>



<!--查看登录日志-->
  <v-btn color="blue" style="font-family: 楷体;position: absolute;right: 12%;bottom: 0%;font-size: 30px;height: 7%"
@click="getLoginRecord"
  >查看登录日志</v-btn>

  <v-dialog
      v-model="ifshowLoginRecord"
      transition="dialog-bottom-transition"
      max-width="700"
      style="height: 600px"
  >
    <div style="overflow:scroll">
    <div style="font-family: '楷体';font-size: 25px;background-color:white;"
    v-for="record in loginRecord" :key="record.id"
    >
      London time:{{record.logintime.split('T')[0]}}    {{record.logintime.split('T')[1]}}
    </div>
    </div>
    <v-btn @click="ifshowLoginRecord=false" color="blue" style="color:white;font-family:楷体;font-size: 20px;"
    >确定</v-btn>
  </v-dialog>






</div>
</template>

<script>
import request from "@/utils/request";

export default {
  name: "TeacherGui",
  data(){
    return{
      allCourses:[],students:[],
      canEnter:true,
      showdialogcourse:false,ifAlertSuccess:false,ifAlertFail:false,showdialognotexit:false,showstudentdialog:false,ifAlertDelete:false,
      confirmdeletedialog:false,ifshowLoginRecord:false,
      valid:true,

      coursename:'',
      courseteacher:sessionStorage.getItem("userName"),
      courseteacherid:sessionStorage.getItem("userId"),
      creditOptions:[1,2,3,4,5],
      credit:'0',
      coursedescription:'',
      choosecoursebegtime:'', choosecourseendtime:'',
      coursebegweeks:[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15], coursebegdays:[1,2,3,4,5,6,7], coursebegcous:[1,2,3,4,5],
      courseendweeks:[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15], courseenddays:[1,2,3,4,5,6,7], courseendcous:[1,2,3,4,5],
      coursebegweek:'',coursebegday:'',coursebegcou:'',
      courseendweek:'',courseendday:'',
      coursebegtime:'', courseendtime:'',

      courseid:"",

      loginRecord:[],

      timeRules:{
        form: value => value.match(/^(\d{4})(-)(\d{2})(-)(\d{2})$/) || '请按要求格式输入',
      },
      nameRules:{
        required: value => !!value || '请填写课程名称',
      },
      creditRules: {
        required: value => value.match(/^[+]{0,1}(\d+)$/) || '请填写数字',
        counter: value => value>=0&&value<=5 || '学分范围是1-5！',
      },
      weekRules: {
        required: value => value.match(/^[+]{0,1}(\d+)$/) || '请填写数字',
        counter: value => value>=0&&value<=15 || '周数必须是1-15！',
      },
      dayRules: {
        required: value => value.match(/^[+]{0,1}(\d+)$/) || '请填写数字',
        counter: value => value>=0&&value<=7 || '周几必须是1-7！',
      },
      couRules: {
        required: value => value.match(/^[+]{0,1}(\d+)$/) || '请填写数字',
        counter: value => value>=0&&value<=5 || '课程时间必须是1-5！',
      },


    }
  },


  methods:{
    exit(){
      sessionStorage.removeItem("userId")
      sessionStorage.removeItem("userName");
      this.$router.push('/');
    },
    toScore(){
      this.$router.push('/teacherEnterScore');
    },
    toCourse(){
      this.$router.push('/teacherEnterCourse');
    },

    check(){
      this.canEnter=this.$refs.form.validate();
      alert(this.canEnter);
    },
    discheck(){
      this.ifAlertSuccess=false;
      this.ifAlertFail=false;
    },

// 得到该老师的课程
    getMyCourse(){
      request.post("/api/teacher/getCourse", {
        courseteacher:this.courseteacher,
      }).then((response) => {
        this.allCourses=response;
        console.log(response);
      })
          .catch((error) => {
            console.log(error);
          });
    },
// 把课程信息展示到dialog中
    showCourseInfo(name,credit,des,begweek,begday,begcou,endweek,endday,choosebegtime,chooseendtime,courseid){
      this.courseid=courseid;
      this.coursename=name;this.credit=credit;this.coursedescription=des;this.coursebegweek=begweek;
      this.coursebegday=begday;this.coursebegcou=begcou;this.courseendweek=endweek;
      this.courseendday=endday;
      this.choosecoursebegtime=choosebegtime;this.choosecourseendtime=chooseendtime;
      this.showdialogcourse=true;
      },

//修改课程信息
    changeCourseInfo(){
      this.canEnter=this.$refs.form.validate();
      if (this.canEnter) {
        this.coursebegtime = this.coursebegweek + "-" + this.coursebegday + "-" + this.coursebegcou;//第几周-周几-第几节
        this.courseendtime = this.courseendweek + "-" + this.courseendday + "-" + this.coursebegcou;
        request.post("/api/teacher/changeCourse", {
          courseid: this.courseid,
          coursename: this.coursename,
          courseteacher: this.courseteacher,
          credit: this.credit,
          coursedescription: this.coursedescription,
          choosecoursebegtime: this.choosecoursebegtime,
          choosecourseendtime: this.choosecourseendtime,
          coursebegtime: this.coursebegtime,
          courseendtime: this.courseendtime,
        }).then((response) => {
          console.log(response);
          if (response.code == 0) {
            this.ifAlertSuccess = true;
            this.getMyCourse();
          }
        })
            .catch((error) => {
              console.log(error);
              this.ifAlertFail = true;
            });
      }
    },

    //获得选择此课程学生
    getStudentChooseCourse(courseid){
      this.courseid=courseid;
      request.post("/api/teacher/getTheCourseStudentUserWithoutGrade",{
        courseid:courseid,
      }) .then( (response) => {
        this.students = response;
        if (this.students.length==0)this.showdialognotexit=true;
        else this.showstudentdialog=true;//showstudentdialog本身调用的便是用for循环读取students信息
        console.log(response);
      })
          .catch((error) => {
            console.log(error);
          });
    },

    //删除课程
    //弹出对话框
    deleteMyCourse(courseid){
      this.confirmdeletedialog=true;
      this.courseid=courseid
    },
    //删除按钮点击删除
    trueDelete(){
        request.post("/api/teacher/deleteCourse",{
          courseid:this.courseid,
        }) .then( (response) => {
          this.confirmdeletedialog=false;
          this.ifAlertDelete=true;
          console.log(response);
          location.reload();
        })
            .catch((error) => {
              console.log(error);
            });
    },


    // 查看登录日志
    getLoginRecord(){
      request.post("/api/user/getRecord",{
        loginuserid:this.courseteacherid,
      }) .then( (response) => {
        console.log(response);
        this.loginRecord=response;
        this.ifshowLoginRecord=true;
      })
          .catch((error) => {
            console.log(error);
          });
    },




  },

  computed:{
    getUserName() {
      return sessionStorage.getItem("userName");
    },
  },

  mounted:function(){
    this.getMyCourse();
  },





}
</script>

<style scoped>
.background {
  background: url("../../assets/background/back04.png") no-repeat;
  background-position: center;
  height: 100%;
  width: 100%;
  background-size: cover;
  position: fixed;
}





</style>