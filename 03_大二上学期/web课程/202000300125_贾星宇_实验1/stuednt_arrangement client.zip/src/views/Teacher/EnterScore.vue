<template>
  <div class="background">
    <!--  顶部按钮组-->
    <div style="font-family: 楷体;position: absolute;top:3%;left: 5%; font-size:30px;">欢迎你,{{courseteacher}}老师</div>
    <div style="font-family: 楷体;position: absolute;top:0%;left: 31%;">
      <v-btn color="teal" style="height: 30%" tile @click="toCourse">
        <div style="font-size: 30px" ><br>录入课程</div>
      </v-btn>
      <v-btn color="primary" style="height: 30%" tile disabled>
        <div style="font-size: 30px"><br>录入成绩</div>
      </v-btn>
      <v-btn color="info" style="height: 30%" tile @click="toGui">
        <div style="font-size: 30px"><br>我的课程</div>
      </v-btn>
    </div>
    <br><br><br><br>
    <v-divider></v-divider>
    <v-btn color="red" style="font-family: 楷体;position: absolute;right: 0%;bottom: 0%;font-size: 30px;height: 7%"
    @click="exit"
    >退出登录</v-btn>

    <v-dialog
        v-model="showdialognotexit"
        transition="dialog-bottom-transition"
        max-width="600"
    >
      <v-card style="color: #503e2a;font-family: '楷体';font-size: 30px;" >
        暂时没有学生选择此门课程
        <br>
        <v-btn style="font-size: 30px;" @click="showdialognotexit=false;">
          确定
        </v-btn>
      </v-card>
    </v-dialog>



    <!--  刷新-->
    <v-btn
        style="color: #503e2a;position: absolute;top: 19%;left: 5%;background-color:rgba(0,0,0,0);"
        elevation="4"
        fab
        large
        raised
        rounded
        @click="getCourse"
    ><v-img src="../../assets/icons/reflesh.png" style="width: 40px"/></v-btn>

    <p style="position: absolute;left: 13%;top: 14%;font-family: '楷体';font-size: 25px;">
      点击课程名称以录入学生成绩：
    </p>

<!--    不同课程按钮组-->
    <div style="position: absolute;left: 10%;top: 20%" >
      <v-btn id="coursenamebtn"
          v-for="tcourse in courses" :key="tcourse.courseid"
             style="color: #503e2a;font-family: '楷体';font-size: 25px; height: 50px;background-color:rgba(0,0,0,0);border:2px solid #503e2a;"
             elevation="16"
             rounded
             @click="getStudentChooseCourse(tcourse.courseid)"
      >
        {{tcourse.courseid+"-"+tcourse.coursename}}
      </v-btn>
    </div>
<!--    不同添加成绩提示框-->
      <v-dialog
          v-model="showdialog"
           transition="dialog-bottom-transition"
           max-width="600"
      >
        <v-alert
            dense
            border="left"
            type="warning"
            v-model="ifAlertNotScore"
        >
          <strong>请输入成绩！</strong>
        </v-alert>
        <v-alert
            dense
            border="left"
            type="success"
            v-model="ifAlertSuccess"
        >
          <strong>成绩保存成功！</strong>
        </v-alert>
        <v-card style="color: #503e2a;font-family: '楷体';font-size: 25px;">
          请输入学生成绩……
          <div v-for="student in students" :key="student.id" @click="ifAlertNotScore=false;ifAlertSuccess=false">
            <v-row>
              <v-col><v-text-field
              :label="student.name"
              v-model="student.grade"
              required
              :rules="[scoreRules.required]"
              style="width: 300px"
              @click="student.grade=''"
              ></v-text-field></v-col>
              <v-col><v-btn style="font-size: 20px;"
                            @click="sendStudentScore(student.id,student.grade)"
              >保存{{student.name}}的成绩</v-btn></v-col>
            </v-row>
          </div>
        </v-card>
      </v-dialog>

  </div>
</template>

<script>
import request from "@/utils/request";
// import Qs from "qs";

export default {
  name: "EnterScore",

  data(){
    return{
      courseteacher:sessionStorage.getItem("userName"),
      courses:[],
      students:[],
      courseid:'',
      userid:'',
      grade:'',
      showdialog:false,showdialognotexit:false,ifAlertNotScore:false,ifAlertSuccess:false,


      scoreRules: {
        required: value => value.match(/^[0-9]*$/) || '请填写正确的成绩格式',
      },



    }
  },
//原理：
//   首先通过查询老师姓名找到该老师所拥有的课程（数据库course）
// 利用v-for来循环生成每个按钮，每个按钮里面都包含了对应课程的所有对象信息
// 点击对应按钮，调用方法，传入参数是课程的id，
// 后端：获得对应课程id，根据数据库choosecourse找到选了该课程的学生id，获得对应数据库对象数组
// 再利用循环依次寻找user中的根据学生id找到的学生信息，以对象数组的形似返回到前端
// 前端用v-for接受，存到了td里面，每个td里面都有该学生对象的所有信息
  methods:{
    exit(){
      sessionStorage.removeItem("userName");
      sessionStorage.removeItem("userId")
      this.$router.push('/');
    },
    toCourse(){
      this.$router.push('/teacherEnterCourse');
    },
    toGui(){
      this.$router.push('/teacherGui');
    },

    getCourse(){
      request.post("/api/teacher/getCourse",{
        courseteacher:this.courseteacher,
      }) .then( (response) => {
        this.courses = response;
        console.log(response);
      })
          .catch((error) => {
            console.log(error);
          });
    },

    getStudentChooseCourse(courseid){
      this.courseid=courseid;
      request.post("/api/teacher/getTheCourseStudentUser",{
        //老师的课程编号
        //如何通过点击不同课程按钮来得到courseid:添加方法参数
        courseid:courseid,

      }) .then( (response) => {
        this.students = response;
        if (this.students.length==0)this.showdialognotexit=true;
        else this.showdialog=true;
        console.log(response);
      })
          .catch((error) => {
            console.log(error);
          });
    },

    sendStudentScore(studentid,grade){
      if (grade=='')this.ifAlertNotScore=true
      else {
        request.post("/api/teacher/setScore", {
          userid: studentid,
          courseid: this.courseid,
          grade: grade,
        }).then((response) => {
          if (response.code == 0) this.ifAlertSuccess=true;
          console.log(response);
        })
            .catch((error) => {
              console.log(error);
            });
      }
    },




  },
  mounted:function(){
    this.getCourse();//需要触发的函数
  },

  computed:{




  },
}
</script>

<style scoped>
.background {
  background: url("../../assets/background/back04.png") no-repeat;
  background-position: center;
  height: 100%;
  width: 100%;
  background-size: cover;
  position: fixed;
}
</style>