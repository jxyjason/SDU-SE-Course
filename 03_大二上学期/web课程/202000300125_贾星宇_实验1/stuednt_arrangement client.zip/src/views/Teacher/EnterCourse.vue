<template>
  <div class="background">
    <!--  顶部按钮组-->
    <div style="font-family: 楷体;position: absolute;top:3%;left: 5%; font-size:30px;">欢迎你,{{courseteacher}}老师</div>
    <div style="font-family: 楷体;position: absolute;top:0%;left: 31%;">
      <v-btn color="teal" style="height: 30%" tile disabled>
        <div style="font-size: 30px" ><br>录入课程</div>
      </v-btn>
      <v-btn color="primary" style="height: 30%" tile @click="toScore">
        <div style="font-size: 30px"><br>录入成绩</div>
      </v-btn>
      <v-btn color="info" style="height: 30%" tile @click="toGui">
        <div style="font-size: 30px"><br>我的课程</div>
      </v-btn>
    </div>
    <br><br><br><br>
    <v-divider></v-divider>
    <v-btn color="red" style="font-family: 楷体;position: absolute;right: 0%;bottom: 0%;font-size: 30px;height: 7%"
           @click="exit"
    >退出登录</v-btn>




    <v-alert
        dense
        border="left"
        type="success"
        v-model="ifAlertSuccess"
    >
      <strong>成功添加课程：{{coursename}}</strong>
    </v-alert>
    <v-alert
        dense
        border="left"
        type="warning"
        v-model="ifAlertFail"
    >
      <strong>"{{coursename}}"添加失败</strong>
    </v-alert>
    <v-alert
        dense
        border="left"
        type="warning"
        v-model="ifAlertChooseBegMaxEnd"
    >
      <strong>"{{coursename}}"选课开始时间大于截止时间！</strong>
    </v-alert>
    <v-alert
        dense
        border="left"
        type="warning"
        v-model="ifAlertBegMaxEnd"
    >
      <strong>"{{coursename}}"课程的开始时间大于课程结束时间！</strong>
    </v-alert>
    <v-alert
        dense
        border="left"
        type="warning"
        v-model="ifAlertSame"
    >
      <strong>"{{coursename}}"课程已存在</strong>
    </v-alert>

<div style="font-family: '楷体';overflow:auto;font-weight: bolder;position: absolute;top:15%;left: 15%;width: 75%;height: 70%" @click="disCheck">
    <v-form
        ref="form"
        v-model="valid"
        lazy-validation
    >
      <v-text-field
          v-model="coursename"
          label="请输入课程名称......"
          :rules="[nameRules.required]"
          required
      ></v-text-field>
      <br>
      <v-select
          :items="creditOptions"
          solo
          label="请选择课程学分……"
          v-model="credit"
      ></v-select>
      <v-text-field
          v-model="coursedescription"
          label="请输入课程描述......"
          required
      ></v-text-field>
      <v-text-field
          v-model="choosecoursebegtime"
          :rules="[timeRules.form]"
          label="请输入该课程选课开始时间(格式:XXXX-XX-XX)..."
          required
      ></v-text-field>
      <v-text-field
          v-model="choosecourseendtime"
          :rules="[timeRules.form]"
          label="请输入该课程选课截止时间(格式:XXXX-XX-XX)..."
          required
      ></v-text-field>
      <br>
      <v-row>
      <v-select
          :items="coursebegweeks"
          solo
          label="请选择课程开始周……"
          v-model="coursebegweek"
      ></v-select>
      <v-select
          :items="coursebegdays"
          solo
          label="请选择课程在周几开设……"
          v-model="coursebegday"
      ></v-select>
      <v-select
          :items="coursebegcous"
          solo
          label="请选择课程在第几节课开设……"
          v-model="coursebegcou"
      ></v-select>
      </v-row>
      <v-row>
        <v-select
            :items="courseendweeks"
            solo
            label="请选择课程结束周……"
            v-model="courseendweek"
        ></v-select>
        <v-select
            :items="courseenddays"
            solo
            label="请选择课程在周几结束……"
            v-model="courseendday"
        ></v-select>
      </v-row>



    </v-form>
</div>

<!--    添加课程-->
    <v-btn
        style="color: #503e2a;font-family: '楷体';font-size: 50px;position: absolute;bottom:6%;left: 40%; height: 60px;background-color:rgba(0,0,0,0);border:2px solid #503e2a;"
        elevation="16"
        rounded
        @click="check();submitCourse()"
    >确认添加</v-btn>
    <!--  刷新-->
    <v-btn
        style="color: #503e2a;position: absolute;top: 16%;left: 8%;background-color:rgba(0,0,0,0);"
        elevation="4"
        fab
        large
        raised
        rounded
        @click="clean"
    ><v-img src="../../assets/icons/reflesh.png" style="width: 40px"/></v-btn>








  </div>
</template>

<script>
import request from "@/utils/request";

export default {
  name: "EnterClass",
  data(){
    return{
      coursename:'',
      courseteacher:sessionStorage.getItem("userName"),
      creditOptions:[1,2,3,4,5],
      credit:'0',
      coursedescription:'',
      choosecoursebegtime:'', choosecourseendtime:'',
      coursebegweeks:[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15], coursebegdays:[1,2,3,4,5,6,7], coursebegcous:[1,2,3,4,5],
      courseendweeks:[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15], courseenddays:[1,2,3,4,5,6,7], courseendcous:[1,2,3,4,5],
      coursebegweek:'',coursebegday:'',coursebegcou:'',
      courseendweek:'',courseendday:'',
      coursebegtime:'', courseendtime:'',

      canEnter:true,
      valid:true,
      ifAlertSuccess:false, ifAlertFail:false, ifAlertSame:false,ifAlertChooseBegMaxEnd:false,ifAlertBegMaxEnd:false,

      timeRules:{
        form: value => value.match(/^(\d{4})(-)(\d{2})(-)(\d{2})$/) || '请按要求格式输入',
      },
      nameRules:{
        required: value => !!value || '请填写课程名称',
      },



    }
  },

  methods:{
    exit(){
      sessionStorage.removeItem("userId")
      sessionStorage.removeItem("userName");
      this.$router.push('/');
    },
    toScore(){
      this.$router.push('/teacherEnterScore');
    },
    toGui(){
      this.$router.push('/teacherGui');
    },
    check(){
      this.canEnter=this.$refs.form.validate();
      if (this.credits==0||this.coursebegweek==''||this.courseendweek==''||this.coursebegday==''||
      this.courseendday==''||this.coursebegcou==''||this.courseendcou=='')this.canEnter=false;
      this.checkTime();
    },
    checkTime(){
      var cbeginDate = new Date(this.choosecoursebegtime);
      var cendDate = new Date(this.choosecourseendtime);

      if (this.coursebegweek>this.courseendweek){
        this.ifAlertBegMaxEnd=true;
        this.canEnter=false;
      }else if (cbeginDate>cendDate){
        this.ifAlertChooseBegMaxEnd=true;
        this.canEnter=false;
      }
    },
    disCheck(){
      this.ifAlertFail=false;
      this.ifAlertSuccess=false;
      this.ifAlertSame=false;
      this.ifAlertChooseBegMaxEnd=false;
      this.ifAlertBegMaxEnd=false;
    },
    clean(){
      this.$refs.form.reset();
    },

    submitCourse(){
      this.coursebegtime=this.coursebegweek+"-"+this.coursebegday+"-"+this.coursebegcou;//第几周-周几-第几节
      this.courseendtime=this.courseendweek+"-"+this.courseendday+"-"+this.coursebegcou;
      if (this.canEnter==true){
        request.post("/api/teacher/addCourse",{
          coursename:this.coursename,
          courseteacher:this.courseteacher,
          credit:this.credit,
          coursedescription:this.coursedescription,
          choosecoursebegtime:this.choosecoursebegtime,
          choosecourseendtime:this.choosecourseendtime,
          coursebegtime:this.coursebegtime,
          courseendtime:this.courseendtime,
        }) .then( (response) => {
          console.log(response);
          if (response.code==0) {
            this.ifAlertSuccess=true;
          }else if (response.code==1){
            this.ifAlertSame=true;
          }
        })
            .catch((error) => {
              console.log(error);
              this.ifAlertFail=true;
            });


      }
    }



  },


  computed:{


  },
}
</script>

<style scoped>
.background {
  background: url("../../assets/background/back04.png") no-repeat;
  background-position: center;
  height: 100%;
  width: 100%;
  background-size: cover;
  position: fixed;
}
</style>