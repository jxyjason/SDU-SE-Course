<template>
<div class="background">
  <!--  顶部按钮组-->
  <div style="font-family: 楷体;position: absolute;top:3%;left: 5%; font-size:30px;">欢迎你,{{t_studentname}}同学</div>
  <div style="font-family: 楷体;position: absolute;top:0%;left: 31%;">
    <v-btn color="teal" style="height: 30%" tile @click="toChooseCourse">
      <div style="font-size: 30px" ><br>进入选课</div>
    </v-btn>
    <v-btn color="primary" style="height: 30%" tile disabled>
      <div style="font-size: 30px"><br>我的课程</div>
    </v-btn>
    <v-btn color="info" style="height: 30%" tile @click="toMyScore">
      <div style="font-size: 30px"><br>我的成绩</div>
    </v-btn>
  </div>
  <br><br><br><br>
  <v-divider></v-divider>
  <v-btn color="red" style="font-family: 楷体;position: absolute;right: 0%;bottom: 0%;font-size: 30px;height: 7%"
         @click="exit"
  >退出登录</v-btn>



  <v-alert
      dense
      border="left"
      type="success"
      v-model="ifAlertSuccess"
  >
    <strong>退课成功！</strong>
  </v-alert>

<!--我的课程-->
  <!--    课程简介-->
  <v-dialog
      v-model="showdialogcoursedes"
      transition="dialog-bottom-transition"
      max-width="600"
  >
    <v-card style="color: #503e2a;font-family: '楷体';font-size: 30px;" >
      {{courseDescription}}
      <br>
      <v-btn style="font-size: 20px;" @click="showdialogcoursedes=false;">
        确定
      </v-btn>
    </v-card>
  </v-dialog>

  <!--课程div-->
  <div  @click="nocheck"  style="font-family: '楷体';font-size:15px;overflow:auto;font-weight: bolder;position: absolute;top:15%;left: 5%;width: 70%;height: 70%">
    <div v-for="course in myCourses" :key="course.courseid" >
      <v-chip color="success" outlined style="width: 300px;height: 50px" v-scroll @click="seeCourseDescription(course.coursedescription)">
        <v-icon left>mdi-star</v-icon>
        <div style="font-family: '楷体';font-size:15px;">课程：(点击查看课程简介)<br>{{course.coursename}}</div>
      </v-chip>

      <v-chip color="indigo" outlined style="width: 250px;height: 50px">
        <v-avatar left>
          <v-icon>mdi-account-circle</v-icon>
        </v-avatar>
        <div style="font-family: '楷体';font-size:20px;">授课教师：{{course.courseteacher}}</div>
      </v-chip>

      <v-avatar
          color="blue"
          size="48"
          style="color: white;font-size: 30px"
      >
        <span>{{course.credit}}<div style="font-size: 15px">学分</div></span>
      </v-avatar>

      <v-chip color="deep-purple accent-4" outlined style="width: 350px;height: 50px" v-scroll>
        <v-icon left>mdi-server-plus</v-icon>
        <div style="font-family: '楷体';font-size:15px;">
          课程起止时间：<br>{{"第"+course.coursebegtime.split("-")[0]+"周，周"+course.coursebegtime.split("-")[1]+"第"+
        course.coursebegtime.split("-")[2]+"节课"}}至{{"第"+course.courseendtime.split("-")[0]+"周，周"+course.courseendtime.split("-")[1]+
        "第"+course.courseendtime.split("-")[2]+"节课"}}
        </div>

      </v-chip>

      <v-btn style="font-size: 20px" color="red" outlined @click="courseidTemp=course.courseid;showdialogifdelete=true"
             ><v-img src="../../assets/icons/wrong.png" style="height: 20px;width: 20px;color: red"></v-img>退选课程：
        {{course.coursename}}</v-btn>

      <br><br>
    </div>
  </div>

<!--确定退选-->
  <v-dialog
      v-model="showdialogifdelete"
      transition="dialog-bottom-transition"
      max-width="600"
  >
    <v-card style="color: #503e2a;font-family: '楷体';font-size: 30px;" >
      确定退选该课程？
      <br>
      <v-btn color="red" style="font-size: 20px;color: white;" @click="deleteSpecialCourse(courseidTemp);showdialogifdelete=false">
        确定
      </v-btn>
      <v-btn color="blue" style="font-size: 20px;color:white;" @click="showdialogifdelete=false">
        取消
      </v-btn>
    </v-card>
  </v-dialog>







<!--我的课程表-->
  <v-btn style="font-size: 25px;font-family: 楷体;position: absolute;right: 10%;top:30%;color:white;"
         color="blue"
      @click="seeTable">查看我的课表</v-btn>

  <v-dialog
      v-model="showdialogcoursetable"
      transition="dialog-bottom-transition"
      max-width="1000"
  >
  <div style="overflow: auto" >
    <v-simple-table>
      <thead>
      <tr>
        <th v-for="week in weeks" :key="week">
          <div style="font-size: 20px;font-family: 楷体;"><strong>{{ week }}</strong></div>
        </th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="i in 5" :key="i" height="100px">
        <td><div style="font-size: 20px;font-family: 楷体;"><strong>{{ i }}</strong></div></td>
        <td v-for="j in 7" :key="j" >
          <div style="font-size: 20px;font-family: 楷体;"
               v-for="myCourse in myCourses" :key="myCourse.courseid">
            <div v-if="myCourse.coursebegtime.split('-')[1].match(j)&&myCourse.coursebegtime.split('-')[2].match(i)">
              <strong>{{myCourse.coursename}}</strong><br>授课教师：<strong>{{myCourse.courseteacher}}</strong>
            </div>
          </div>
        </td>
      </tr>
      </tbody>
    </v-simple-table>
  </div>
  </v-dialog>


<!--信息维护-->
  <v-btn style="font-size: 25px;font-family: 楷体;position: absolute;right: 7%;top:20%;color:white;"
         color="blue" @click="getMyInfo">查看我的个人信息</v-btn>
  <v-dialog
      v-model="showdialogMyMessage"
      transition="dialog-bottom-transition"
      max-width="1000"
  >
    <v-alert
        dense dismissible
        border="left"
        type="success"
        v-model="ifAlertSuccessSaveMyInfo"
    >
      <strong>保存成功！</strong>
    </v-alert>


    <div style="font-size: 25px;font-family: 楷体;background-color:white;">
      <v-form
          ref="form"
          v-model="valid"
          lazy-validation
      >
      <v-text-field
          v-model="tname"
          :rules="[nameRules.required]"
          label="姓名"
          required
      ></v-text-field>

      <v-text-field
          v-model="tid"
          label="学号："
          :rules="[idRules.required, idRules.counter]"
          required disabled
      ></v-text-field>

      <v-text-field
          v-model="tgrade"
          label="班级："
          required
      ></v-text-field>
      <v-text-field
          v-model="tmajor"
          :rules="[majorRules.required]"
          label="专业："
          required
      ></v-text-field>

      <v-text-field
          v-model="tbirth"
          label="生日：(格式：XXXX-XX-XX)"
          :rules="[birthRules.form]"
          required
      ></v-text-field>

      <v-text-field
          v-model="tpasssafe"
          label="密保："
          required
      ></v-text-field>


      <v-text-field
          v-model="temail"
          :rules="[emailRuels.form]"
          label="邮箱"
          required
      ></v-text-field>


      <v-text-field
          v-model="tphone"
          :rules="[phoneRuels.form]"
          label="手机："
          required
      ></v-text-field>


      <v-text-field
          v-model="taddress"
          label="地址："
          required
      ></v-text-field>

      <v-btn style="font-size: 25px;font-family: 楷体;background-color: lightskyblue;color: white"
      @click="changeInfo"
      >点击保存信息</v-btn>
      </v-form>
    </div>
  </v-dialog>




  <!--查看登录日志-->
  <v-btn color="blue" style="font-family: 楷体;position: absolute;right: 12%;bottom: 0%;font-size: 30px;height: 7%"
         @click="getLoginRecord"
  >查看登录日志</v-btn>

  <v-dialog
      v-model="ifshowLoginRecord"
      transition="dialog-bottom-transition"
      max-width="700"
      style="height: 600px"
  >
    <div style="font-family: '楷体';font-size: 25px;background-color:white;"
         v-for="record in loginRecord" :key="record.id"
    >
      London time:{{record.logintime.split('T')[0]}}    {{record.logintime.split('T')[1]}}
    </div>
    <v-btn @click="ifshowLoginRecord=false" color="blue" style="color:white;font-family:楷体;font-size: 20px;"
    >确定</v-btn>
  </v-dialog>





</div>
</template>

<script>
import request from "@/utils/request";

export default {
  name: "StudentGui",
  data(){
    return{
      valid: true,

      t_studentname:sessionStorage.getItem("userName"),
      t_studentid:sessionStorage.getItem("userId"),

      weeks:["","星期一","星期二","星期三","星期四","星期五","星期六","星期日",],
      courses:[],//生成课表的课程
      myCourses:[],//该生所有课程
      loginRecord:[],

      showdialogcoursetable:false, showdialogcoursedes:false, showdialogifdelete:false,showdialogMyMessage:false,
      courseDescription:'',ifshowLoginRecord:false,
      //用于确定退选 把上方v-for循环中对象的内容取出来
      courseidTemp:'',

      ifAlertSuccess:false,ifAlertSuccessSaveMyInfo:false,


      //维护个人信息
      tuser:'',
      tname:'',
      tid: '',
      tgrade:'',
      tmajor:'',
      tbirth:'',
      tpasssafe:'',
      temail:'',
      tphone:'',
      taddress:'',
      nameRules:{
        required: value => !!value || '请填写姓名',
      },
      idRules: {
        required: value => !!value || '请填写账号',
        counter: value => value.length == 6 || '账号必须是六位数字！',
      },
      majorRules:{
        required: value => !!value || '请填写专业',
      },
      birthRules:{
        form: value => value.match(/^(\d{4})(-)(\d{2})(-)(\d{2})$/) || '请按要求格式输入',
      },
      emailRuels:{
        form: value => value.match(/^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/) || '请输入正确邮箱',
      },
      phoneRuels:{
        form: value => value.match(/^1[3456789]\d{9}$/) || '请输入正确的手机号码',
      },

    }
  },

  methods:{
    seeTable(){this.showdialogcoursetable=true;},
    exit(){
      sessionStorage.removeItem("userName");
      sessionStorage.removeItem("userId")
      this.$router.push('/');
    },
    toChooseCourse(){
      this.$router.push('/enterChooseCourse');
    },
    toMyScore(){
      this.$router.push('/enterMyScore')
    },
    seeCourseDescription(des){
      this.courseDescription=des;
      this.showdialogcoursedes=true;
    },
    nocheck() {
      this.ifAlertSuccess=false;
    },

    //得到该生选的所有课程
    gerMyCourses(){
      request.post("/api/student/getMyCourses", {
        userid:this.t_studentid,
      }).then((response) => {
        this.myCourses=response;
        console.log(response);
      })
          .catch((error) => {
            console.log(error);
          });
    },

    //删除课程
    deleteSpecialCourse(courseid){
      request.post("/api/student/deleteSpecialCourses", {
        userid:this.t_studentid,
        courseid:courseid,
      }).then((response) => {
        if (response.code=='0'){
          this.ifAlertSuccess=true;
          location.reload();
        }
        console.log(response);
      })
          .catch((error) => {
            console.log(error);
          });
    },

    //得到个人信息
    getMyInfo(){
        request.post("/api/student/getMyInfo", {
          id: this.t_studentid,
        }).then((response) => {
          this.tuser = response;
          this.tname = response.name;
          this.tid = response.id;
          this.tgrade = response.grade;
          this.tmajor = response.major;
          this.tbirth = response.birth;
          this.tpasssafe = response.passsafe;
          this.temail = response.email;
          this.tphone = response.phone;
          this.taddress = response.address;
          console.log(response);
          this.showdialogMyMessage = true;

        })
            .catch((error) => {
              console.log(error);
            });
    },

    changeInfo(){
      request.post("/api/student/changeMyInfo", {
        id:this.tid,
        name:this.tname,
        grade:this.tgrade,
        major:this.tmajor,
        birth:this.tbirth,
        passsafe:this.tpasssafe,
        email:this.temail,
        phone:this.tphone,
        address:this.taddress,
      }).then((response) => {
        console.log(response);
        if (response.code==0)this.ifAlertSuccessSaveMyInfo=true;
      })
          .catch((error) => {
            console.log(error);
          });
    },

    // 查看登录日志
    getLoginRecord(){
      request.post("/api/user/getRecord",{
        loginuserid:this.t_studentid,
      }) .then( (response) => {
        console.log(response);
        this.loginRecord=response;
        this.ifshowLoginRecord=true;
      })
          .catch((error) => {
            console.log(error);
          });
    },




  },



  computed: {
    getUserName() {
      return sessionStorage.getItem("userName");
    },
  },
  mounted:function(){
    this.gerMyCourses();
    this.getCourseTable();
  },
}
</script>

<style scoped>
.background {
  background: url("../../assets/background/back02.jpg") no-repeat;
  background-position: center;
  height: 100%;
  width: 100%;
  background-size: cover;
  position: fixed;
}
</style>