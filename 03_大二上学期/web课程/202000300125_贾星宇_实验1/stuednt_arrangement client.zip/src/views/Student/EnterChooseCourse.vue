d<template>
  <div class="background">
    <!--  顶部按钮组-->
    <div style="font-family: 楷体;position: absolute;top:3%;left: 5%; font-size:30px;">欢迎你,{{t_studentname}}同学</div>
    <div style="font-family: 楷体;position: absolute;top:0%;left: 31%;">
      <v-btn color="teal" style="height: 30%" tile disabled>
        <div style="font-size: 30px" ><br>进入选课</div>
      </v-btn>
      <v-btn color="primary" style="height: 30%" tile @click="toGui">
        <div style="font-size: 30px"><br>我的课程</div>
      </v-btn>
      <v-btn color="info" style="height: 30%" tile @click="toMyScore">
        <div style="font-size: 30px"><br>我的成绩</div>
      </v-btn>
    </div>
    <br><br><br><br>
    <v-divider></v-divider>
    <v-btn color="red" style="font-family: 楷体;position: absolute;right: 0%;bottom: 0%;font-size: 30px;height: 7%"
           @click="exit"
    >退出登录</v-btn>



    <v-alert
        dense
        border="left"
        type="success"
        v-model="ifAlertSuccess"
    >
      <strong>选课成功！</strong>
    </v-alert>
    <v-alert
        dense
        border="left"
        type="warning"
        v-model="ifAlertHavaChoosed"
    >
      <strong>您已选过此课程！</strong>
    </v-alert>
    <v-alert
        dense
        border="left"
        type="warning"
        v-model="ifAlertTimeBattle"
    >
      <strong>该课程时间与你选过的课程时间冲突！</strong>
    </v-alert>
    <v-alert
        dense
        border="left"
        type="warning" dismissible
        v-model="ifAlertWrongTime"
    >
      <strong>此课程还未开始选课或已超过选课时间！</strong>
    </v-alert>


<!--    课程简介-->
    <v-dialog
        v-model="showdialogcoursedes"
        transition="dialog-bottom-transition"
        max-width="600"
    >
      <v-card style="color: #503e2a;font-family: '楷体';font-size: 30px;" >
        {{courseDescription}}
        <br>
        <v-btn style="font-size: 20px;" @click="showdialogcoursedes=false;">
          确定
        </v-btn>
      </v-card>
    </v-dialog>

<!--课程div-->
    <div @click="clearAllAlert()"  style="font-family: '楷体';font-size:15px;overflow:auto;font-weight: bolder;position: absolute;top:15%;left: 5%;width: 70%;height: 70%">
      <div v-for="course in allCourses" :key="course.courseid" >
        <v-chip color="success" outlined style="width: 300px;height: 50px" v-scroll @click="seeCourseDescription(course.coursedescription)">
          <v-icon left>mdi-star</v-icon>
          <div style="font-family: '楷体';font-size:15px;">课程：(点击查看课程简介)<br>{{course.coursename}}</div>
        </v-chip>

        <v-chip color="indigo" outlined style="width: 250px;height: 50px">
          <v-avatar left>
            <v-icon>mdi-account-circle</v-icon>
          </v-avatar>
          <div style="font-family: '楷体';font-size:20px;">授课教师：{{course.courseteacher}}</div>
        </v-chip>

        <v-avatar
            color="blue"
            size="48"
            style="color: white;font-size: 30px"
        >
          <span>{{course.credit}}<div style="font-size: 15px">学分</div></span>
        </v-avatar>

        <v-chip color="deep-purple accent-4" outlined style="width: 350px;height: 50px" v-scroll>
          <v-icon left>mdi-server-plus</v-icon>
          <div style="font-family: '楷体';font-size:15px;">
            课程起止时间：<br>{{"第"+course.coursebegtime.split("-")[0]+"周，周"+course.coursebegtime.split("-")[1]+"第"+
          course.coursebegtime.split("-")[2]+"节课"}}至{{"第"+course.courseendtime.split("-")[0]+"周，周"+course.courseendtime.split("-")[1]+
          "第"+course.courseendtime.split("-")[2]+"节课"}}
          </div>

        </v-chip>

        <v-btn style="font-size: 20px" color="indigo darken-3" outlined
               @click="addChooseCourse(course.courseid,course.choosecoursebegtime,course.choosecourseendtime)">选择课程：
          {{course.coursename}}</v-btn>

        <br><br>



      </div>
    </div>













  </div>
</template>

<script>
import request from "@/utils/request";

export default {
  name: "EnterChooseCourse",

  data(){
    return{
      t_studentname:sessionStorage.getItem("userName"),
      t_studentid:sessionStorage.getItem("userId"),
      allCourses:[],
      showdialogcoursedes:false,ifAlertHavaChoosed:false,ifAlertSuccess:false,ifAlertWrongTime:false,ifAlertTimeBattle:false,
      courseDescription:'',


    }
  },

  methods:{
    exit(){
      sessionStorage.removeItem("userId")
      sessionStorage.removeItem("userName");
      this.$router.push('/');
    },
    toMyScore(){
      this.$router.push('/enterMyScore')
    },
    toGui(){
      this.$router.push('/studentGui')
    },
    seeCourseDescription(des){
      this.courseDescription=des;
      this.showdialogcoursedes=true;
    },
    clearAllAlert(){
      this.ifAlertSuccess=false;
      this.ifAlertHavaChoosed=false;
      this.ifAlertTimeBattle=false;
    },


    getAllCourse(){
      request.post("/api/student/getAllCourse", {
      }).then((response) => {
        this.allCourses=response;
        console.log(response);
      })
          .catch((error) => {
            console.log(error);
          });
    },

    addChooseCourse(courseid,choosebeg,chooseend){
      var cbeginDate = new Date(choosebeg);
      var cendDate = new Date(chooseend);
      var today = new Date();
      if (cbeginDate<=today&&today<=cendDate) {
        request.post("/api/student/chooseCourse", {
          userid: this.t_studentid,
          courseid: courseid,
        }).then((response) => {
          if (response.code == 1) this.ifAlertHavaChoosed = true;
          else if (response.code==2)this.ifAlertTimeBattle=true;
          else this.ifAlertSuccess = true;
          console.log(response);
        })
            .catch((error) => {
              console.log(error);
            });
      }else this.ifAlertWrongTime=true;
    }




  },

  mounted:function(){
    this.getAllCourse();
  },

}

</script>

<style scoped>
.background {
  background: url("../../assets/background/back02.jpg") no-repeat;
  background-position: center;
  height: 100%;
  width: 100%;
  background-size: cover;
  position: fixed;
}
</style>