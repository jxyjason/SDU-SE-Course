<template>
<div class="background">
  <!--  顶部按钮组-->
  <div style="font-family: 楷体;position: absolute;top:3%;left: 5%; font-size:30px;">欢迎你,{{t_studentname}}同学</div>
  <div style="font-family: 楷体;position: absolute;top:0%;left: 31%;">
    <v-btn color="teal" style="height: 30%" tile @click="toChooseCourse">
      <div style="font-size: 30px" ><br>进入选课</div>
    </v-btn>
    <v-btn color="primary" style="height: 30%" tile @click="toGui">
      <div style="font-size: 30px"><br>我的课程</div>
    </v-btn>
    <v-btn color="info" style="height: 30%" tile disabled>
      <div style="font-size: 30px"><br>我的成绩</div>
    </v-btn>
  </div>
  <br><br><br><br>
  <v-divider></v-divider>
  <v-btn color="red" style="font-family: 楷体;position: absolute;right: 0%;bottom: 0%;font-size: 30px;height: 7%"
         @click="exit"
  >退出登录</v-btn>



<!--  点击课程查看成绩-->
  <div style="position: absolute;top:13%;left: 30%;font-size: 35px;font-family: 楷体;">
    点<br>击<br>不<br>同<br>课<br>程
  </div>
  <div style="position: absolute;top:18%;left: 34%;font-size: 35px;font-family: 楷体;">
    查<br>看<br>我<br>的<br>成<br>绩
  </div>
  <!--课程div-->
  <div style="font-family: '楷体';font-size:15px;overflow:auto;font-weight: bolder;position: absolute;top:15%;left: 45%;width: 30%;height: 45%">
    <div v-for="course in myCourses" :key="course.courseid" >
      <v-chip color="success" outlined style="width: 300px;height: 50px" v-scroll
              @click="getInfo(course.courseid)">
        <v-icon left>mdi-star</v-icon>
        <div style="font-family: '楷体';font-size:15px;">课程：(点击查看此门课程成绩)<br>{{course.coursename}}</div>
      </v-chip>

      <br><br>
    </div>
  </div>

  <v-dialog
      v-model="showdialogscore"
      transition="dialog-bottom-transition"
      max-width="600"
  >
    <v-card style="color: #503e2a;font-family: '楷体';font-size: 30px;">
      你的成绩是：{{courseScore}}分<br>你在班级内名次为：{{levelInClass}}<br>你的总名次为：{{levelInMajor}}
      <br>
      <v-btn color="blue" style="font-size: 25px;color: white;" @click="showdialogscore=false;">
        确定
      </v-btn>
    </v-card>
  </v-dialog>























</div>
</template>

<script>
import request from "@/utils/request";

export default {
  name: "EnterMyScore",

  data(){
    return{
      t_studentname:sessionStorage.getItem("userName"),
      t_studentid:sessionStorage.getItem("userId"),

      myCourses:[],
      showdialogscore:false,
      courseScore:'',levelInClass:'',levelInMajor:'',

    }
  },

  methods:{
    exit(){
      sessionStorage.removeItem("userId")
      sessionStorage.removeItem("userName");
      this.$router.push('/');
    },
    toChooseCourse(){
      this.$router.push('/enterChooseCourse');
    },
    toMyScore(){
      this.$router.push('/enterMyScore')
    },
    toGui(){
      this.$router.push('/studentGui')
    },



    //得到该生选的所有课程
    gerMyCourses(){
      request.post("/api/student/getMyCourses", {
        userid:this.t_studentid,
      }).then((response) => {
        this.myCourses=response;
        console.log(response);
      })
          .catch((error) => {
            console.log(error);
          });
    },

    //得到dialog所有信息
    getInfo(courseid){
      this.showdialogscore=true;
      this.seeCourseScore(courseid);
      this.getLevelInMajor(courseid);
      this.getLevelInClass(courseid);
    },

//查看课程成绩
    seeCourseScore(courseid){
      request.post("/api/student/getTheChooseCourseByStudentID", {
        userid:this.t_studentid,
        courseid:courseid,
      }).then((response) => {
        this.courseScore=response.grade;
        console.log(response);
      })
          .catch((error) => {
            console.log(error);
          });
    },

    //查看班级排名
    getLevelInClass(courseid){
      request.post("/api/student/getTheLevelInClass", {
        userid:this.t_studentid,
        courseid:courseid
      }).then((response) =>{
        this.levelInClass = response.msg;
        console.log(response);
      })
          .catch((error) => {
            console.log(error);
          });
    },

    //查看专业排名
    getLevelInMajor(courseid){
      request.post("/api/student/getTheLevelInMajor", {
        userid:this.t_studentid,
        courseid:courseid
      }).then((response) =>{
        this.levelInMajor = response.msg;
        console.log(response);
      })
          .catch((error) => {
            console.log(error);
          });
    }





  },



  mounted:function(){
    this.gerMyCourses();
  },
}
</script>

<style scoped>
.background {
  background: url("../../assets/background/back03.png") no-repeat;
  background-position: center;
  height: 100%;
  width: 100%;
  background-size: cover;
  position: fixed;
}
</style>