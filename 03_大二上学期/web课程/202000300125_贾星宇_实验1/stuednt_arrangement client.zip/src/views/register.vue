<template>
<div class="background">
  <v-alert
      dense
      border="left"
      type="warning"
      v-model="ifAlertWarning"
  >
    请输入<strong>完整且正确</strong>的信息
  </v-alert>
    <v-alert
        dense
        border="left"
        type="warning"
        v-model="ifAlertFail"
    >
      <strong>用户已注册</strong>
  </v-alert>
    <v-alert
        dense
        border="left"
        type="warning"
        v-model="ifAlertNotEqu"
    >
      两次输入的密码<strong>不一致</strong>
  </v-alert>
  <v-alert
      dense
      border="left"
      type="success"
      v-model="ifAlertSuccess"
  >
    <strong>注册成功！</strong>
  </v-alert>



  <p id="p-log"
     style="color: #503e2a;font-family: '楷体';font-size: 90px;position: absolute;bottom: 35%;left: 9%;"
  >注<br>册</p>

<div style="font-family: '楷体';overflow:auto;font-weight: bolder;position: absolute;top:10%;left: 20%;width: 50%;height: 70%"
@click="disCheck"
>
  <v-form
      ref="form"
      v-model="valid"
      lazy-validation
  >
    <v-text-field
        v-model="name"
        :rules="[nameRules.required]"
        label="姓名"
        required
    ></v-text-field>

    <v-text-field
        v-model="id"
        label="学号："
        :rules="[idRules.required, idRules.counter]"
        required
    ></v-text-field>

    <v-text-field
        v-model="password"
        label="密码："
        :rules="[passwordRules.required, passwordRules.counter]"
        required

        :type="passwordshow ? 'text' : 'password'"
        :append-icon="passwordshow ? 'mdi-eye' : 'mdi-eye-off'"
        @click:append="passwordshow = !passwordshow"
    ></v-text-field>

    <v-text-field
        v-model="confirmPassword"
        label="确认密码："
        :rules="[passwordRules.required, passwordRules.counter]"
        required

        :type="passwordshow ? 'text' : 'password'"
        :append-icon="passwordshow ? 'mdi-eye' : 'mdi-eye-off'"
        @click:append="passwordshow = !passwordshow"
    ></v-text-field>
    <br>
    <v-select
        :items="gradeOptions"
        solo
        label="请选择班级……"
        v-model="grade"
    ></v-select>

    <v-text-field
        v-model="major"
        :rules="[majorRules.required]"
        label="专业："
        required
    ></v-text-field>

    <v-text-field
        v-model="birth"
        label="生日：(格式：XXXX-XX-XX)"
        :rules="[birthRules.form]"
        required
    ></v-text-field>

    <v-text-field
        v-model="passsafe"
        label="密保："
        required
    ></v-text-field>


    <v-text-field
        v-model="email"
        :rules="[emailRuels.form]"
        label="邮箱"
        required
    ></v-text-field>


    <v-text-field
        v-model="phone"
        :rules="[phoneRuels.form]"
        label="手机："
        required
    ></v-text-field>


    <v-text-field
        v-model="address"
        label="地址："
        required
    ></v-text-field>
我的身份：
    <v-radio-group
        v-model="userType"
        row
        style="font-size: large"
    >
      <v-radio
          label="我是老师"
          value="0"
          @click="disCheck"
      ></v-radio>
      <v-radio
          label="我是学生"
          value="1"
          @click="disCheck"
      ></v-radio>
    </v-radio-group>


  </v-form>
</div>




  <!--  注册-->
  <v-btn
      style="color: #503e2a;font-family: '楷体';font-size: 50px;position: absolute;bottom: 67%;left: 75%; height: 60px;background-color:rgba(0,0,0,0);border:2px solid #503e2a;"
      elevation="16"
      rounded
      @click="check();register()"
  >注册</v-btn>
  <!--  刷新-->
  <v-btn
      style="color: #503e2a;position: absolute;bottom: 50%;left: 75%;background-color:rgba(0,0,0,0);"
      elevation="4"
      fab
      large
      raised
      rounded
      @click="clean"
  ><v-img src="../assets/icons/reflesh.png" style="width: 40px"/></v-btn>
  <!--  返回-->
  <v-btn
      style="position: absolute;top: 5%;left: 3%;background-color:rgba(0,0,0,0);"
      elevation="2"
      fab
      large
      raised
      rounded
      @click="back"
  ><v-img src="../assets/icons/back.png" style="width: 40px"/></v-btn>
</div>
</template>





<script>
import request from "@/utils/request";
export default {
  name: "register",
  data(){
    return{
      valid: true,

      name:'',
      id: '',
      password:'',
      confirmPassword:'',
      gradeOptions:[1,2,3,4,5],
      grade:'',
      major:'',
      birth:'',
      passsafe:'',
      email:'',
      phone:'',
      address:'',
      userType:-1,

      canEnter:true,
      ifAlertWarning:false,ifAlertNotEqu:false,ifAlertSuccess:false,ifAlertFail:false,
      passwordshow:false,//密码是否可见
      nameRules:{
        required: value => !!value || '请填写姓名',
      },
      idRules: {
        required: value => !!value || '请填写账号',
        counter: value => value.length == 6 || '账号必须是六位数字！',
      },
      passwordRules: {
        required: value => !!value || '请填写密码',
        counter: value => value.length == 6 || '密码必须是六位数字！',
      },
      majorRules:{
        required: value => !!value || '请填写专业',
      },
      birthRules:{
        form: value => value.match(/^(\d{4})(-)(\d{2})(-)(\d{2})$/) || '请按要求格式输入',
      },
      emailRuels:{
        form: value => value.match(/^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/) || '请输入正确邮箱',
      },
      phoneRuels:{
        form: value => value.match(/^1[3456789]\d{9}$/) || '请输入正确的手机号码',
      },

    }
  },

  methods:{
    back(){
      this.$router.push('/');
    },
    check(){
      this.canEnter=this.$refs.form.validate();
      if (!this.canEnter)this.ifAlertWarning=true;
      if (this.userType==-1)this.canEnter=false;
      if (this.password!=this.confirmPassword){
        this.canEnter=false;
        this.ifAlertNotEqu=true;
      }
    },
    disCheck(){
      this.ifAlertWarning=false;
      this.ifAlertSuccess = false;
      this.ifAlertNotEqu = false;
      this.ifAlertFail = false;
      this.canEnter=true;
    },
    clean(){
      this.$refs.form.reset();
    },

    register() {
      if (this.canEnter){
        request.post("/api/user/register",{
          name:this.name,
          id : this.id,
          password: this.password,
          grade:this.grade,
          major:this.major,
          birth:this.birth,
          passsafe:this.passsafe,
          email:this.email,
          phone:this.phone,
          address:this.address,
          usertype:this.userType,
        }) .then( (response) => {
          console.log(response);
          if (response.code==0){
            this.ifAlertSuccess=true;
          }
       })
      .catch((error) => {
        this.ifAlertFail=true;
        console.log(error);
      });

        }

    },
  }
}

</script>

<style scoped>
.background {
  background: url("../assets/background/back02.jpg") no-repeat;
  background-position: center;
  height: 100%;
  width: 100%;
  background-size: cover;
  position: fixed;
}
</style>