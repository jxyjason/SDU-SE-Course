import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/login.vue'
import Register from '../views/register.vue'
import Forget from '../views/forget.vue'
import TeacherGui from '../views/Teacher/TeacherGui.vue'
import StudentGui from '../views/Student/StudentGui.vue'
import TeacherEnterScore from '../views/Teacher/EnterScore.vue'
import TeacherEnterCourse from '../views/Teacher/EnterCourse.vue'
import EnterChooseCourse from "@/views/Student/EnterChooseCourse";
import EnterMyScore from "@/views/Student/EnterMyScore";


Vue.use(VueRouter)

const routes = [

  {
    path: '/',
    name: 'Login',
    component: Login
  },
  {
    path: '/register',
    name: 'Register',
    component: Register
  },
  {
    path: '/forget',
    name: 'Forget',
    component: Forget
  },
  {
    path: '/teacherGui',
    name: 'TeacherGui',
    component: TeacherGui
  },
  {
    path: '/teacherEnterScore',
    name: 'TeacherEnterScore',
    component: TeacherEnterScore
  },
  {
    path: '/teacherEnterCourse',
    name: 'TeacherEnterCourse',
    component: TeacherEnterCourse
  },
  {
    path: '/studentGui',
    name: 'StudentGui',
    component: StudentGui
  },
  {
    path: '/enterChooseCourse',
    name: 'EnterChooseCourse',
    component: EnterChooseCourse
  },
  {
    path: '/enterMyScore',
    name: 'EnterMyScore',
    component: EnterMyScore
  },

]

const router = new VueRouter({
  routes
})

export default router
