package com.example.student_arrangement.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.student_arrangement.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface UserMapper extends BaseMapper<User>{

    @Select("select * from `user` where id = #{id}")
    public User selectUserById(@Param("id")String id);
    @Select("select * from `user` where password = #{password}")
    public User selectUserByPass(@Param("password")String password);

    @Select("select * from `user` where id = #{id} and password = #{password}")
    public User selectUserByIdAndPass(@Param("id")String id,@Param("password")String password);

    @Select("select * from `user` where type = #{type}")
    public User selectUserByType(@Param("type")String type);
    @Select("select * from `user` where id = #{id} and password = #{password} and usertype = #{type}")
    public User selectUserByAll(@Param("id")String id,@Param("password")String password,@Param("type")String type);


    @Select("select * from `user` where id=#{id} and passsafe = #{passsafe}")
    public User selectUserByPasssafeAndId(@Param("id")String id,@Param("passsafe")String passsafe);

    @Update("UPDATE `student_arrangement`.`user` SET `password` = #{password} WHERE (`id` = #{id})")
    public void changePassword(@Param("password")String password,@Param("id")String id);

    @Update("UPDATE `student_arrangement`.`user` SET `name` = #{name}, `grade` = #{grade} ,`major` = #{major}, " +
            "`birth` = #{birth}, `passsafe` = #{passsafe}, `email` =#{email}, `phone` = #{phone}," +
            "`address` = #{address} WHERE (`id` = #{id})")
    public void changeInfo(@Param("name")String name,@Param("grade")String grade,@Param("major")String major,
                           @Param("birth")String birth,@Param("passsafe")String passsafe,@Param("email")String email,
                           @Param("phone")String phone,@Param("address")String address,@Param("id")String id);


}
