package com.example.student_arrangement.controller;


import com.example.student_arrangement.common.Result;
import com.example.student_arrangement.entity.ChooseCourse;
import com.example.student_arrangement.entity.Course;
import com.example.student_arrangement.entity.User;
import com.example.student_arrangement.mapper.ChooseCourseMapper;
import com.example.student_arrangement.mapper.CourseMapper;
import com.example.student_arrangement.mapper.UserMapper;
import com.example.student_arrangement.ownset.CreateNewTable;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

@RestController
@CrossOrigin

@RequestMapping(value = "/teacher")
public class TeacherController {
    @Resource
    UserMapper userMapper;
    @Resource
    CourseMapper courseMapper;
    @Resource
    ChooseCourseMapper chooseCourseMapper;


    //保存写好的课程
    @RequestMapping(value = "/addCourse",method = RequestMethod.POST)
    public Result<?> saveCourse(@RequestBody Course course) throws SQLException, ClassNotFoundException {
        //new CreateNewTable().create(course.getCoursename());
        Course tcourse = courseMapper.selectByCoursename(course.getCoursename());
        if(!ObjectUtils.isEmpty(tcourse)){
            return Result.srror("1","exist the course!");
        }else {
            courseMapper.insertcourse(course.getCoursename(),course.getCourseteacher(),course.getCredit(),
                    course.getCoursedescription(),course.getChoosecoursebegtime(),course.getChoosecourseendtime(),
                    course.getCoursebegtime(),course.getCourseendtime());//插入到数据库里面
            return Result.success();
        }
    }
//得到自己的课程
    @RequestMapping(value = "/getCourse",method = RequestMethod.POST)
    public List<Course> getCourse(@RequestBody Course course){
        List<Course> tcourse = courseMapper.selectByCourseteacher(course.getCourseteacher());
        return tcourse;
    }


//得到选择此课程的学生的所有信息，把成绩暂存到grade
    @RequestMapping(value = "/getTheCourseStudentUser",method = RequestMethod.POST)
    public User[] getTheCourseStudentUser(@RequestBody ChooseCourse chooseCourse){
        ChooseCourse courseList[] = chooseCourseMapper.selectChooseUserByCourseIdarr(chooseCourse.getCourseid());
        User user[] = new User[courseList.length];
        for (int i=0;i<courseList.length;i++){
            user[i] = userMapper.selectUserById(courseList[i].getUserid());
            user[i].setGrade(String.valueOf(courseList[i].getGrade()));
        }
        return user;
    }
//得到学生的所有信息，成绩不暂存
    @RequestMapping(value = "/getTheCourseStudentUserWithoutGrade",method = RequestMethod.POST)
    public User[] getTheCourseStudentUserWithoutGrade(@RequestBody ChooseCourse chooseCourse){
        ChooseCourse courseList[] = chooseCourseMapper.selectChooseUserByCourseIdarr(chooseCourse.getCourseid());
        User user[] = new User[courseList.length];
        for (int i=0;i<courseList.length;i++){
            user[i] = userMapper.selectUserById(courseList[i].getUserid());
        }
        return user;
    }
//设置学生的成绩
    @RequestMapping(value = "/setScore",method = RequestMethod.POST)
    public Result setGrade(@RequestBody ChooseCourse chooseCourse){
        ChooseCourse cc = chooseCourseMapper.selectChooseUserByUserIdAndCourseId(chooseCourse.getUserid(),chooseCourse.getCourseid());
        if(ObjectUtils.isEmpty(cc)){
            return Result.srror("1","don't find user or course!");
        }else {
            chooseCourseMapper.updateGradeByUseridAndCourseid(chooseCourse.getGrade(),
                    chooseCourse.getUserid(), chooseCourse.getCourseid());
            return Result.success();
        }
    }
//修改课程
    @RequestMapping(value = "/changeCourse",method = RequestMethod.POST)
    public Result changeCourse(@RequestBody Course course){
        courseMapper.updateCourseById(course.getCoursename(),course.getCredit(),course.getCoursedescription(),course.getChoosecoursebegtime(),
        course.getChoosecourseendtime(),course.getCoursebegtime(),course.getCourseendtime(),course.getCourseid());
        return Result.success();
    }
//删除课程
    @RequestMapping(value = "/deleteCourse",method = RequestMethod.POST)
    public Result deleteCourse(@RequestBody Course course){
        courseMapper.deleteCourseById(course.getCourseid());
        chooseCourseMapper.deleteCourseByCourseid(course.getCourseid());
        return Result.success();
    }













}
