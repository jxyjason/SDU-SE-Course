package com.example.student_arrangement.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.student_arrangement.entity.Course;
import com.example.student_arrangement.entity.User;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface CourseMapper extends BaseMapper<Course> {

    @Select("select * from `course`")
    public List<Course> selectAllCourse();

    @Select("select * from `course` where coursename = #{coursename}")
    public Course selectByCoursename(@Param("coursename")String coursename);

    @Select("select * from `course` where courseteacher = #{courseteacher}")
    public List<Course> selectByCourseteacher(@Param("courseteacher")String courseteacher);

    @Select("select * from `course` where courseid = #{courseid}")
    public Course selectByCourseId(@Param("courseid")String courseid);

    @Insert("INSERT INTO `student_arrangement`.`course` " +
            "(`coursename`, `courseteacher`, `credit`, `coursedescription`, `choosecoursebegtime`, " +
            "`choosecourseendtime`, `coursebegtime`, `courseendtime`) VALUES (#{coursename}, #{courseteacher}, " +
            "#{credit}, #{coursedescription}, #{choosecoursebegtime}, #{choosecourseendtime}, #{coursebegtime}," +
            " #{courseendtime})")
    public void insertcourse(
            @Param("coursename")String coursename,@Param("courseteacher")String courseteacher,
            @Param("credit")String credit,@Param("coursedescription")String coursedescription,
            @Param("choosecoursebegtime")String choosecoursebegtime,@Param("choosecourseendtime")String choosecourseendtime,
            @Param("coursebegtime")String coursebegtime,@Param("courseendtime")String courseendtime

    );

    @Update("UPDATE `student_arrangement`.`course` SET `coursename` = #{coursename}, `credit` = #{credit}, " +
            "`coursedescription` = #{coursedescription}," + " `choosecoursebegtime` = #{choosecoursebegtime}, " +
            "`choosecourseendtime` = #{choosecourseendtime}, `coursebegtime` = #{coursebegtime}, `courseendtime` = #{courseendtime} " +
            "WHERE (`courseid` = #{courseid})")
    public void updateCourseById(@Param("coursename")String coursename, @Param("credit")String credit,
                                 @Param("coursedescription")String coursedescription, @Param("choosecoursebegtime")String choosecoursebegtime,
                                 @Param("choosecourseendtime")String choosecourseendtime, @Param("coursebegtime")String coursebegtime,
                                 @Param("courseendtime")String courseendtime,@Param("courseid")int courseid);

    @Delete("DELETE FROM `student_arrangement`.`course` WHERE (`courseid` = #{courseid})")
    public void deleteCourseById(@Param("courseid")int courseid);





}
