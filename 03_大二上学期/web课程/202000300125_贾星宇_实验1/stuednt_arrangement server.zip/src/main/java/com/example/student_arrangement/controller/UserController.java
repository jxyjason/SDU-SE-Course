package com.example.student_arrangement.controller;


import com.example.student_arrangement.common.Result;
import com.example.student_arrangement.entity.LoginRecord;
import com.example.student_arrangement.entity.User;
import com.example.student_arrangement.mapper.LoginRecordMapper;
import com.example.student_arrangement.mapper.UserMapper;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

//前后台数据交互的接口 接收信息转成user类
@RestController
@CrossOrigin

@RequestMapping(value = "/user")
public class UserController {
    @Resource
    UserMapper userMapper;
    @Resource
    LoginRecordMapper loginRecordMapper;

    //接口的路由
    //注册
    @RequestMapping(value = "/register",method = RequestMethod.POST)
    public Result<?> save(@RequestBody User user){
        userMapper.insert(user);//插入到数据库里面
        return Result.success();
    }
//登录
    @RequestMapping(value = "/login",method = RequestMethod.POST)
    public Result<?> login(@RequestBody User user){
        User tuser=userMapper.selectUserById(user.getId());
        if(!ObjectUtils.isEmpty(tuser)){
            tuser=userMapper.selectUserByAll(user.getId(),user.getPassword(),user.getUsertype());
            if (!ObjectUtils.isEmpty(tuser)) return Result.srror("0",tuser.getId(),tuser.getName());       //登录成功！
                else return Result.srror("1","wrong password!");
        }else{
            return Result.srror("2","wrong user!");
        }
    }
//忘记密码
    @RequestMapping(value = "/forget",method = RequestMethod.POST)
    public Result<?> forget(@RequestBody User user){
        User tuser=userMapper.selectUserById(user.getId());
        if (!ObjectUtils.isEmpty(tuser)){
            tuser=userMapper.selectUserByPasssafeAndId(user.getId(),user.getPasssafe());
            if (!ObjectUtils.isEmpty(tuser)){
                return Result.srror("0",tuser.getPassword());
            }else return Result.srror("1","wrong passsafe!");
        }else{
            return Result.srror("2","wrong user!");
        }
    }

    //修改密码
    @RequestMapping(value = "/changePassword",method = RequestMethod.POST)
    public Result<?> changePassword(@RequestBody User user){
        User tuser=userMapper.selectUserById(user.getId());
        if(!ObjectUtils.isEmpty(tuser)){
            tuser=userMapper.selectUserByIdAndPass(user.getId(),user.getPassword());
            if (!ObjectUtils.isEmpty(tuser)){
                userMapper.changePassword(user.getGrade(),user.getId());
                return Result.success();
            }
            else return Result.srror("1","wrong password!");
        }else{
            return Result.srror("2","wrong user!");
        }
    }

    //添加登录记录
    @RequestMapping(value = "/addRecord",method = RequestMethod.POST)
    public Result<?> save(@RequestBody LoginRecord loginRecord){
        loginRecordMapper.addLoginRecord(loginRecord.getLogintime(),loginRecord.getLoginuserid());
        return Result.success();
    }

//获取登陆记录
    @RequestMapping(value = "/getRecord",method = RequestMethod.POST)
    public LoginRecord[] getRecord(@RequestBody LoginRecord loginRecord){
        return loginRecordMapper.selectByUserId(loginRecord.getLoginuserid());
    }







}
