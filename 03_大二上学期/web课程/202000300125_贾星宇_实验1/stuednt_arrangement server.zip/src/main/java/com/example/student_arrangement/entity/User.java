package com.example.student_arrangement.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@TableName("user")
@Data
public class User {
    @TableId(type = IdType.AUTO,value = "id")
    private String id;
    private String name;
    private String password;
    private String grade;
    private String major;
    private String birth;
    private String passsafe;
    private String email;
    private String phone;
    private String address;
    private String usertype;


    public User(String id, String name, String password, String grade, String major, String birth, String passsafe, String email, String phone, String address, String usertype) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.grade = grade;
        this.major = major;
        this.birth = birth;
        this.passsafe = passsafe;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.usertype = usertype;
    }
    public User(){}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getBirth() {
        return birth;
    }

    public void setBirth(String birth) {
        this.birth = birth;
    }

    public String getPasssafe() {
        return passsafe;
    }

    public void setPasssafe(String passsafe) {
        this.passsafe = passsafe;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUsertype() {
        return usertype;
    }

    public void setUsertype(String usertype) {
        this.usertype = usertype;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public User(String id, String password) {
        this.id = id;
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", password='" + password + '\'' +
                ", grade='" + grade + '\'' +
                ", major='" + major + '\'' +
                ", birth='" + birth + '\'' +
                ", passsafe='" + passsafe + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", address='" + address + '\'' +
                ", usertype='" + usertype + '\'' +
                '}';
    }
}
