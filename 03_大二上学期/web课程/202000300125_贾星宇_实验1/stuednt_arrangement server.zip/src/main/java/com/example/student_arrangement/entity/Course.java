package com.example.student_arrangement.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.example.student_arrangement.common.Result;
import lombok.Data;

@TableName("course")
@Data
public class Course {

    @TableId(type = IdType.AUTO,value = "courseid")
    private int courseid;
    private String coursename;
    private String courseteacher;
    private String credit;
    private String coursedescription;
    private String choosecoursebegtime;
    private String choosecourseendtime;
    private String coursebegtime;
    private String courseendtime;

    public Course(int courseid, String coursename, String courseteacher, String credit, String coursedescription, String choosecoursebegtime, String choosecourseendtime, String coursebegtime, String courseendtime) {
        this.courseid = courseid;
        this.coursename = coursename;
        this.courseteacher = courseteacher;
        this.credit = credit;
        this.coursedescription = coursedescription;
        this.choosecoursebegtime = choosecoursebegtime;
        this.choosecourseendtime = choosecourseendtime;
        this.coursebegtime = coursebegtime;
        this.courseendtime = courseendtime;
    }

    public int getCourseid() {
        return courseid;
    }

    public void setCourseid(int courseid) {
        this.courseid = courseid;
    }

    @Override
    public String toString() {
        return "Course{" +
                "courseid=" + courseid +
                ", coursename='" + coursename + '\'' +
                ", courseteacher='" + courseteacher + '\'' +
                ", credit='" + credit + '\'' +
                ", coursedescription='" + coursedescription + '\'' +
                ", choosecoursebegtime='" + choosecoursebegtime + '\'' +
                ", choosecourseendtime='" + choosecourseendtime + '\'' +
                ", coursebegtime='" + coursebegtime + '\'' +
                ", courseendtime='" + courseendtime + '\'' +
                '}';
    }

    public String getCoursedescription() {
        return coursedescription;
    }

    public void setCoursedescription(String coursedescription) {
        this.coursedescription = coursedescription;
    }



    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

    public String getCourseteacher() {
        return courseteacher;
    }

    public void setCourseteacher(String courseteacher) {
        this.courseteacher = courseteacher;
    }

    public String getCredit() {
        return credit;
    }

    public void setCredit(String credit) {
        this.credit = credit;
    }

    public String getChoosecoursebegtime() {
        return choosecoursebegtime;
    }

    public void setChoosecoursebegtime(String choosecoursebegtime) {
        this.choosecoursebegtime = choosecoursebegtime;
    }

    public String getChoosecourseendtime() {
        return choosecourseendtime;
    }

    public void setChoosecourseendtime(String choosecourseendtime) {
        this.choosecourseendtime = choosecourseendtime;
    }

    public String getCoursebegtime() {
        return coursebegtime;
    }

    public void setCoursebegtime(String coursebegtime) {
        this.coursebegtime = coursebegtime;
    }

    public String getCourseendtime() {
        return courseendtime;
    }

    public void setCourseendtime(String courseendtime) {
        this.courseendtime = courseendtime;
    }

}
