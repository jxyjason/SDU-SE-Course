package com.example.student_arrangement.controller;


import com.example.student_arrangement.common.Result;
import com.example.student_arrangement.entity.ChooseCourse;
import com.example.student_arrangement.entity.Course;
import com.example.student_arrangement.entity.User;
import com.example.student_arrangement.mapper.ChooseCourseMapper;
import com.example.student_arrangement.mapper.CourseMapper;
import com.example.student_arrangement.mapper.UserMapper;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@CrossOrigin

@RequestMapping(value = "/student")
public class StudentController {
    @Resource
    UserMapper userMapper;
    @Resource
    CourseMapper courseMapper;
    @Resource
    ChooseCourseMapper chooseCourseMapper;

    //获取选择的课程
    @RequestMapping(value = "/getAllCourse",method = RequestMethod.POST)
    public List<Course> getCourse(@RequestBody Course course){
        List<Course> tcourse = courseMapper.selectAllCourse();
        return tcourse;
    }

    //选课：返回了userid和courseid，根据courseid找到该课程起止时间，根据userid找到用户当前选择的所有课程，比对
    @RequestMapping(value = "/chooseCourse",method = RequestMethod.POST)
    public Result chooseCourse(@RequestBody ChooseCourse chooseCourse){
        ChooseCourse course = chooseCourseMapper.selectChooseUserByUserIdAndCourseId(chooseCourse.getUserid(),chooseCourse.getCourseid());
        if (!ObjectUtils.isEmpty(course)) return Result.srror("1","have selected!");
        else {

            Course tCourse = courseMapper.selectByCourseId(chooseCourse.getCourseid());
            String tCourseBegWeek = tCourse.getCoursebegtime().split("-")[0];
            String tCourseEndWeek = tCourse.getCourseendtime().split("-")[0];
            String tCourseWeek = tCourse.getCoursebegtime().split("-")[1];
            String tCourseTime = tCourse.getCoursebegtime().split("-")[2];
            ChooseCourse hisChooseCourse[] = chooseCourseMapper.selectChooseUserByUserIdarr(chooseCourse.getUserid());
            for (int i=0;i<hisChooseCourse.length;i++){
                Course hisCourse = courseMapper.selectByCourseId(hisChooseCourse[i].getCourseid());
                String BegWeek = hisCourse.getCoursebegtime().split("-")[0];
                String EndWeek = hisCourse.getCourseendtime().split("-")[0];
                String Week = hisCourse.getCoursebegtime().split("-")[1];
                String Time = hisCourse.getCoursebegtime().split("-")[2];
                if (Integer.parseInt(BegWeek)>Integer.parseInt(tCourseBegWeek)){
                    if (Integer.parseInt(BegWeek)<=Integer.parseInt(tCourseEndWeek)){
                        if (tCourseWeek.equals(Week)&&tCourseTime.equals(Time))
                        return Result.srror("2","time battle!");
                    }
                }else if (Integer.parseInt(BegWeek)<Integer.parseInt(tCourseBegWeek)){
                    if (Integer.parseInt(EndWeek)>=Integer.parseInt(tCourseEndWeek)){
                        if (tCourseWeek.equals(Week)&&tCourseTime.equals(Time))
                        return Result.srror("2","time battle!");
                    }
                }else if (Integer.parseInt(BegWeek)==Integer.parseInt(tCourseBegWeek)){
                    if (tCourseWeek.equals(Week)&&tCourseTime.equals(Time))
                    return Result.srror("2","time battle!");
                }
            }

            chooseCourseMapper.insertChooseCourse(chooseCourse.getUserid(),chooseCourse.getCourseid());
            return Result.success();
        }
    }


    //收到userid，返回该生所有课程
    @RequestMapping(value = "/getMyCourses",method = RequestMethod.POST)
    public Course[] getMyCourses(@RequestBody ChooseCourse chooseCourse){
        ChooseCourse cCourse[] = chooseCourseMapper.selectChooseUserByUserIdarr(chooseCourse.getUserid());
        Course result[] = new Course[cCourse.length];
        for (int i=0;i<cCourse.length;i++)
            if (cCourse[i].getIfchoose().equals("1"))
            result[i] = courseMapper.selectByCourseId(cCourse[i].getCourseid());
        return result;
    }


    //收到userid courseid，删除课程
    @RequestMapping(value = "/deleteSpecialCourses",method = RequestMethod.POST)
    public Result deleteSpecialCourses(@RequestBody ChooseCourse chooseCourse){
        chooseCourseMapper.deleteCourseByUseridAndCourseid(chooseCourse.getUserid(),chooseCourse.getCourseid());
        return Result.success();
    }

    //得到对应课程学生成绩
    @RequestMapping(value = "/getTheChooseCourseByStudentID",method = RequestMethod.POST)
    public ChooseCourse getTheChooseCourseByStudentID(@RequestBody ChooseCourse chooseCourse){
        return chooseCourseMapper.selectChooseUserByUserIdAndCourseId(chooseCourse.getUserid(),chooseCourse.getCourseid());
    }


    //userid,ifchoose(begintime 0-week-course)
    //根据学生id选出学生所有课程，根据课程开设时间选出对应课程
    @RequestMapping(value = "/getSpecialCourseByTime",method = RequestMethod.POST)
    public Course getSpecialCourseByTime(@RequestBody ChooseCourse chooseCourse){
        ChooseCourse cCourse[] = chooseCourseMapper.selectChooseUserByUserIdarr(chooseCourse.getUserid());
        int j=0;
        Course temp[] = new Course[cCourse.length];
        for (int i=0;i<cCourse.length;i++) temp[i] = courseMapper.selectByCourseId(cCourse[i].getCourseid());//得到该生选的所有课程
        String time[] = chooseCourse.getIfchoose().split("-");
        //计算符合条件项目个数
        for (int i=0;i<temp.length;i++){
            if (temp[i].getCoursebegtime().split("-")[1].equals(time[1])&&
                    temp[i].getCoursebegtime().split("-")[2].equals(time[2])){
                return temp[i];
            }
        }
        return new Course(0,"0","0","0","0","0",
                "0","0","0");
    }

    //得到学生在班级内排名
    @RequestMapping(value = "/getTheLevelInClass",method = RequestMethod.POST)
    public Result getTheLevelInClass(@RequestBody ChooseCourse chooseCourse){
        String result = "";String userGrade="";
        //得到该课程所有学生
        ChooseCourse cCourse[] = chooseCourseMapper.selectChooseUserByCourseIdarr(chooseCourse.getCourseid());
        int count=0;
        for (int i=0;i<cCourse.length;i++){
            if (userMapper.selectUserById(cCourse[i].getUserid()).getGrade().equals
                    (userMapper.selectUserById(chooseCourse.getUserid()).getGrade()))count++;
        }
        ChooseCourse MChooseCourse[] = new ChooseCourse[count];
        count=0;
        for (int i=0;i<cCourse.length;i++){
            if (userMapper.selectUserById(cCourse[i].getUserid()).getGrade().equals
                    (userMapper.selectUserById(chooseCourse.getUserid()).getGrade())){
                MChooseCourse[count] = cCourse[i];
                count++;
            }
        }

        int num = MChooseCourse.length;
        for (int i=0;i<num;i++){
            int max = i;
            for (int j=i+1;j<num;j++){
                if (MChooseCourse[j].getGrade()>MChooseCourse[max].getGrade())max = j;
            }
            ChooseCourse temp = MChooseCourse[max];
            MChooseCourse[max] = MChooseCourse[i];
            MChooseCourse[i] = temp;
        }
        for (int i=0;i<num;i++){
            if (MChooseCourse[i].getUserid().equals(chooseCourse.getUserid()))result = String.valueOf(i+1);
        }

        return Result.srror("0",result);
    }


    //得到学生在该专业的总排名
    //返回：学生id，课程id
    @RequestMapping(value = "/getTheLevelInMajor",method = RequestMethod.POST)
    public Result getTheLevelInMajor(@RequestBody ChooseCourse chooseCourse){
        //得到该课程所有学生
        ChooseCourse cCourse[] = chooseCourseMapper.selectChooseUserByCourseIdarr(chooseCourse.getCourseid());
        //排序
        int num = cCourse.length;
        for (int i=0;i<num;i++){
            int max = i;
            for (int j=i+1;j<num;j++){
                if (cCourse[j].getGrade()>cCourse[max].getGrade())max = j;
            }
            ChooseCourse temp = cCourse[max];
            cCourse[max] = cCourse[i];
            cCourse[i] = temp;
        }
        String result="";
        for (int i=0;i<num;i++){
            if (cCourse[i].getUserid().equals(chooseCourse.getUserid()))result = String.valueOf(i+1);
        }
        return Result.srror("0",result);
    }


//得到个人信息
@RequestMapping(value = "/getMyInfo",method = RequestMethod.POST)
public User getMyInfo(@RequestBody User user){
    return userMapper.selectUserById(user.getId());
}

    @RequestMapping(value = "/changeMyInfo",method = RequestMethod.POST)
    public Result changeMyInfo(@RequestBody User user){
        System.out.println(user);
        userMapper.changeInfo(user.getName(),user.getGrade(),user.getMajor(),user.getBirth(),user.getPasssafe(),user.getEmail(),
                user.getPhone(),user.getAddress(),user.getId());
        return Result.success();
    }







}
