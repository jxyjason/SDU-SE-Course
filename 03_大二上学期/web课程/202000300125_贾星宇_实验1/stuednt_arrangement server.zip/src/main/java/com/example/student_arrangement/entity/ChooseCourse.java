package com.example.student_arrangement.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@TableName("choosecourse")
@Data
public class ChooseCourse {
    @TableId(type = IdType.AUTO,value = "courseid")
    private String userid;
    private String courseid;
    private String ifchoose;
    private int grade;

    @Override
    public String toString() {
        return "ChooseCourse{" +
                "userid='" + userid + '\'' +
                ", courseid='" + courseid + '\'' +
                ", ifchoose='" + ifchoose + '\'' +
                ", grade=" + grade +
                '}';
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getCourseid() {
        return courseid;
    }

    public void setCourseid(String courseid) {
        this.courseid = courseid;
    }

    public String getIfchoose() {
        return ifchoose;
    }

    public void setIfchoose(String ifchoose) {
        this.ifchoose = ifchoose;
    }
}
