package com.example.student_arrangement.mapper;


import com.example.student_arrangement.entity.ChooseCourse;
import com.example.student_arrangement.entity.User;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface ChooseCourseMapper {
    @Select("select * from `choosecourse` where courseid = #{courseid}")
    public List<ChooseCourse> selectChooseUserByCourseId(@Param("courseid")String courseid);

    @Select("select * from `choosecourse` where courseid = #{courseid}")
    public ChooseCourse[] selectChooseUserByCourseIdarr(@Param("courseid")String courseid);

    @Select("select * from `choosecourse` where userid = #{userid}")
    public ChooseCourse[] selectChooseUserByUserIdarr(@Param("userid")String userid);

    @Select("select * from `choosecourse` where userid = #{userid} and courseid = #{courseid}")
    public ChooseCourse selectChooseUserByUserIdAndCourseId(@Param("userid")String userid,@Param("courseid")String courseid);


    @Update("UPDATE `student_arrangement`.`choosecourse` SET `grade` = #{grade} WHERE userid = #{userid} and courseid = #{courseid}")
    public void updateGradeByUseridAndCourseid(@Param("grade")int grade,@Param("userid")String userid,@Param("courseid")String courseid);

    @Insert("INSERT INTO `student_arrangement`.`choosecourse` (`userid`, `courseid`, `grade`, `ifchoose`) VALUES (#{userid}, #{courseid},'0', '1')")
    public void insertChooseCourse(@Param("userid")String userid,@Param("courseid")String courseid);

    @Delete("DELETE FROM `student_arrangement`.`choosecourse` WHERE userid = #{userid} and courseid = #{courseid}")
    public void deleteCourseByUseridAndCourseid(@Param("userid")String userid,@Param("courseid")String courseid);

    @Delete("DELETE FROM `student_arrangement`.`choosecourse` WHERE courseid = #{courseid}")
    public void deleteCourseByCourseid(@Param("courseid")int courseid);

}
