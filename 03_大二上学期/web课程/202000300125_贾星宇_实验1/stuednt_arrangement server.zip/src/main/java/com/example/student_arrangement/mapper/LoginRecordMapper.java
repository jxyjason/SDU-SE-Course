package com.example.student_arrangement.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.student_arrangement.entity.Course;
import com.example.student_arrangement.entity.LoginRecord;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface LoginRecordMapper  extends BaseMapper<LoginRecord> {
    @Select("select * from `student_arrangement`.`loginrecord` where loginuserid=#{loginuserid}")
    public LoginRecord[] selectByUserId(@Param("loginuserid")String loginuserid);


    @Insert("INSERT INTO `student_arrangement`.`loginrecord` (`logintime`, `loginuserid`) " +
            "VALUES (#{logintime},#{loginuserid})")
    public void addLoginRecord(@Param("logintime")String logintime,@Param("loginuserid")String loginuserid);




}
