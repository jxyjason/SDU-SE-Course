由于初始化问题，在构建spaceID时lab6lab7用了不同的方法（lab6用了bitmap，lab7用了数组），所以lab7实验单独在另一个系统中运行才可以成功，所以有两个文件：
nachos-3.4-ualr-2022 lab2-6 中有lab2到lab6的实验代码
nachos-3.4-ualr-2022 lab7    中是lab7的实验代码